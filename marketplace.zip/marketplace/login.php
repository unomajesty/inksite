<?php
session_start();
require_once 'db_connect.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    
    // Using SHA1 for password verification
    $hashed_password = sha1($password);
    
    $query = "SELECT * FROM users WHERE username = '$username' AND password = '$hashed_password'";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_name'] = $user['name'];
        
        if ($user['role'] === 'buyer') {
            header('Location: buyer/index.php');
        } else {
            header('Location: seller/index.php');
        }
        exit;
    } else {
        $error = 'Invalid username or password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PropMart - Login</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            background: white;
            border-radius: 30px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            width: 90%;
            max-width: 450px;
            padding: 50px 40px;
            animation: slideUp 0.5s ease;
        }
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .logo {
            text-align: center;
            font-size: 42px;
            font-weight: 800;
            margin-bottom: 20px;
            font-family: 'Playfair Display', serif;
        }
        .logo-primary { color: #667eea; }
        .logo-secondary { color: #f59e0b; }
        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 40px;
            font-size: 16px;
        }
        .form-group { margin-bottom: 25px; }
        label {
            display: block;
            margin-bottom: 8px;
            color: #444;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        input {
            width: 100%;
            padding: 15px;
            border: 2px solid #e0e0e0;
            border-radius: 15px;
            font-size: 16px;
            transition: all 0.3s;
            background: #f8f9fa;
        }
        input:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }
        button {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 15px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px -5px #667eea;
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 12px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 500;
            display: <?php echo $error ? 'block' : 'none'; ?>;
        }
        .demo-box {
            margin-top: 40px;
            padding: 25px;
            background: #f8f9fa;
            border-radius: 20px;
        }
        .demo-title {
            font-weight: 700;
            color: #444;
            margin-bottom: 15px;
            font-size: 16px;
        }
        .demo-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
            background: white;
            border-radius: 12px;
            margin-bottom: 10px;
            border: 1px solid #e0e0e0;
        }
        .demo-item:last-child { margin-bottom: 0; }
        .demo-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }
        .buyer-icon { background: #e3f2fd; color: #1976d2; }
        .seller-icon { background: #e8f5e9; color: #388e3c; }
        .demo-info { flex: 1; }
        .demo-role { font-weight: 600; color: #333; }
        .demo-creds { font-size: 13px; color: #666; }
        .demo-creds strong {
            color: #667eea;
            background: #f0f3ff;
            padding: 2px 8px;
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <span class="logo-primary">Prop</span><span class="logo-secondary">Mart</span>
        </div>
        
        <div class="subtitle">Buy • Sell • Rent • Everything</div>
        
        <?php if ($error): ?>
            <div class="error">❌ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" placeholder="Enter your username" required autofocus>
            </div>
            
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="••••••••" required>
            </div>
            
            <button type="submit">Login to Marketplace</button>
        </form>

        <div class="demo-box">
            <div class="demo-title">🔐 Demo Accounts</div>
            
            <div class="demo-item">
                <div class="demo-icon buyer-icon">👤</div>
                <div class="demo-info">
                    <div class="demo-role">Buyer / Renter</div>
                    <div class="demo-creds">Username: <strong>buyer</strong> • Password: <strong>buyer123@</strong></div>
                </div>
            </div>
            
            <div class="demo-item">
                <div class="demo-icon seller-icon">🏷️</div>
                <div class="demo-info">
                    <div class="demo-role">Seller / Owner</div>
                    <div class="demo-creds">Username: <strong>seller</strong> • Password: <strong>seller##1</strong></div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php
session_start();
require_once '../db_connect.php';

// Check if user is logged in and is buyer
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'buyer') {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Mark messages as read when viewing a conversation
if (isset($_GET['seller_id']) && isset($_GET['product_id'])) {
    $seller_id = (int)$_GET['seller_id'];
    $product_id = (int)$_GET['product_id'];
    
    $mark_read = "UPDATE messages SET is_read = 1 
                  WHERE sender_id = $seller_id 
                  AND receiver_id = $user_id 
                  AND product_id = $product_id 
                  AND is_read = 0";
    mysqli_query($conn, $mark_read);
}

// Get user info
$query = "SELECT * FROM users WHERE id = $user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// Get unread messages count
$unread_query = "SELECT COUNT(*) as count FROM messages WHERE receiver_id = $user_id AND is_read = 0";
$unread_result = mysqli_query($conn, $unread_query);
$unread_count = $unread_result ? mysqli_fetch_assoc($unread_result)['count'] : 0;

// Get cart count
$cart_query = "SELECT COUNT(*) as count FROM cart WHERE user_id = $user_id";
$cart_result = mysqli_query($conn, $cart_query);
$cart_count = $cart_result ? mysqli_fetch_assoc($cart_result)['count'] : 0;

// Get cart items
$cart_query = "
    SELECT c.*, p.title, p.images, p.buy_price, p.rent_price, p.seller_id, u.name as seller_name,
           p.stock, p.low_stock_threshold
    FROM cart c
    JOIN products p ON c.product_id = p.id
    JOIN users u ON p.seller_id = u.id
    WHERE c.user_id = $user_id
    ORDER BY c.created_at DESC
";
$cart_result = mysqli_query($conn, $cart_query);
$cart_items_count = $cart_result ? mysqli_num_rows($cart_result) : 0;

// Handle AJAX requests
if (isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'toggle_save') {
        $product_id = (int)$_POST['product_id'];
        
        $check = "SELECT id FROM saved_items WHERE user_id = $user_id AND product_id = $product_id";
        $check_result = mysqli_query($conn, $check);
        
        if (mysqli_num_rows($check_result) > 0) {
            $delete = "DELETE FROM saved_items WHERE user_id = $user_id AND product_id = $product_id";
            mysqli_query($conn, $delete);
            echo json_encode(['saved' => false]);
        } else {
            $insert = "INSERT INTO saved_items (user_id, product_id) VALUES ($user_id, $product_id)";
            mysqli_query($conn, $insert);
            echo json_encode(['saved' => true]);
        }
        exit;
    }
    
    if ($_POST['action'] === 'add_to_cart') {
        $product_id = (int)$_POST['product_id'];
        $type = mysqli_real_escape_string($conn, $_POST['type']);
        $quantity = (int)$_POST['quantity'];
        $start_date = isset($_POST['start_date']) ? "'" . mysqli_real_escape_string($conn, $_POST['start_date']) . "'" : "NULL";
        $end_date = isset($_POST['end_date']) ? "'" . mysqli_real_escape_string($conn, $_POST['end_date']) . "'" : "NULL";
        
        $check = "SELECT id FROM cart WHERE user_id = $user_id AND product_id = $product_id AND type = '$type'";
        if ($type === 'rent') {
            $check .= " AND start_date = $start_date AND end_date = $end_date";
        }
        $check_result = mysqli_query($conn, $check);
        
        if (mysqli_num_rows($check_result) > 0) {
            echo json_encode(['success' => false, 'error' => 'Item already in cart']);
            exit;
        }
        
        $insert = "INSERT INTO cart (user_id, product_id, type, quantity, start_date, end_date) 
                   VALUES ($user_id, $product_id, '$type', $quantity, $start_date, $end_date)";
        
        if (mysqli_query($conn, $insert)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => mysqli_error($conn)]);
        }
        exit;
    }
    
    if ($_POST['action'] === 'remove_from_cart') {
        $cart_id = (int)$_POST['cart_id'];
        $delete = "DELETE FROM cart WHERE id = $cart_id AND user_id = $user_id";
        mysqli_query($conn, $delete);
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($_POST['action'] === 'send_message') {
        $receiver_id = (int)$_POST['receiver_id'];
        $product_id = (int)$_POST['product_id'];
        $message = mysqli_real_escape_string($conn, $_POST['message']);
        
        $insert = "INSERT INTO messages (sender_id, receiver_id, product_id, message, is_read) 
                   VALUES ($user_id, $receiver_id, $product_id, '$message', 0)";
        mysqli_query($conn, $insert);
        
        $notif_title = "New Message";
        $notif_message = "You have a new message about your product";
        $notif = "INSERT INTO notifications (user_id, type, title, message) 
                  VALUES ($receiver_id, 'message', '$notif_title', '$notif_message')";
        mysqli_query($conn, $notif);
        
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($_POST['action'] === 'create_order') {
        $product_id = (int)$_POST['product_id'];
        $type = mysqli_real_escape_string($conn, $_POST['type']);
        $amount = (float)$_POST['amount'];
        $quantity = (int)$_POST['quantity'];
        $start_date = isset($_POST['start_date']) ? "'" . mysqli_real_escape_string($conn, $_POST['start_date']) . "'" : "NULL";
        $end_date = isset($_POST['end_date']) ? "'" . mysqli_real_escape_string($conn, $_POST['end_date']) . "'" : "NULL";
        
        $stock_check = "SELECT stock FROM products WHERE id = $product_id";
        $stock_result = mysqli_query($conn, $stock_check);
        $product = mysqli_fetch_assoc($stock_result);
        
        if ($product['stock'] < $quantity) {
            echo json_encode(['success' => false, 'error' => 'Insufficient stock']);
            exit;
        }
        
        $prod_query = "SELECT seller_id FROM products WHERE id = $product_id";
        $prod_result = mysqli_query($conn, $prod_query);
        $product_info = mysqli_fetch_assoc($prod_result);
        
        $order_number = 'ORD-' . date('Ymd') . '-' . rand(1000, 9999);
        
        $order = "INSERT INTO orders (order_number, buyer_id, seller_id, product_id, type, quantity, amount, start_date, end_date, status) 
                  VALUES ('$order_number', $user_id, {$product_info['seller_id']}, $product_id, '$type', $quantity, $amount, $start_date, $end_date, 'pending')";
        mysqli_query($conn, $order);
        
        $notif_title = "New Order";
        $notif_message = "You have received a new order #" . $order_number;
        $notif = "INSERT INTO notifications (user_id, type, title, message) 
                  VALUES ({$product_info['seller_id']}, 'order', '$notif_title', '$notif_message')";
        mysqli_query($conn, $notif);
        
        // Remove from cart if it was in cart
        $delete_cart = "DELETE FROM cart WHERE user_id = $user_id AND product_id = $product_id AND type = '$type'";
        mysqli_query($conn, $delete_cart);
        
        echo json_encode(['success' => true, 'order_number' => $order_number]);
        exit;
    }
    
    if ($_POST['action'] === 'checkout_cart') {
        $cart_items = json_decode($_POST['items'], true);
        
        mysqli_begin_transaction($conn);
        
        try {
            foreach ($cart_items as $item) {
                $product_id = $item['product_id'];
                $type = $item['type'];
                $quantity = $item['quantity'];
                $amount = $item['amount'];
                $start_date = isset($item['start_date']) ? "'" . $item['start_date'] . "'" : "NULL";
                $end_date = isset($item['end_date']) ? "'" . $item['end_date'] . "'" : "NULL";
                
                $prod_query = "SELECT seller_id FROM products WHERE id = $product_id";
                $prod_result = mysqli_query($conn, $prod_query);
                $product_info = mysqli_fetch_assoc($prod_result);
                
                $order_number = 'ORD-' . date('Ymd') . '-' . rand(1000, 9999);
                
                $order = "INSERT INTO orders (order_number, buyer_id, seller_id, product_id, type, quantity, amount, start_date, end_date, status) 
                          VALUES ('$order_number', $user_id, {$product_info['seller_id']}, $product_id, '$type', $quantity, $amount, $start_date, $end_date, 'pending')";
                mysqli_query($conn, $order);
            }
            
            $clear = "DELETE FROM cart WHERE user_id = $user_id";
            mysqli_query($conn, $clear);
            
            mysqli_commit($conn);
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            mysqli_rollback($conn);
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }
}

// Get products
$products_query = "
    SELECT p.*, u.name as seller_name, u.avatar as seller_avatar, u.verified as seller_verified,
           (SELECT COUNT(*) FROM saved_items WHERE user_id = $user_id AND product_id = p.id) as is_saved,
           CASE 
               WHEN p.stock = 0 THEN 'out_of_stock'
               WHEN p.stock <= p.low_stock_threshold THEN 'low_stock'
               ELSE 'in_stock'
           END as stock_status
    FROM products p
    JOIN users u ON p.seller_id = u.id
    WHERE p.status = 'active'
    ORDER BY 
        CASE 
            WHEN p.stock = 0 THEN 2
            ELSE 1
        END,
        p.created_at DESC
";
$products_result = mysqli_query($conn, $products_query);

// Get saved items
$saved_query = "
    SELECT p.*, u.name as seller_name, u.id as seller_id,
           CASE 
               WHEN p.stock = 0 THEN 'out_of_stock'
               WHEN p.stock <= p.low_stock_threshold THEN 'low_stock'
               ELSE 'in_stock'
           END as stock_status
    FROM products p
    JOIN saved_items s ON p.id = s.product_id
    JOIN users u ON p.seller_id = u.id
    WHERE s.user_id = $user_id
";
$saved_result = mysqli_query($conn, $saved_query);

// Get messages
$messages_query = "
    SELECT 
           p.id as product_id,
           p.title as product_title,
           p.images,
           p.stock,
           p.low_stock_threshold,
           u.id as seller_id, 
           u.name as seller_name, 
           u.avatar,
           (SELECT COUNT(*) FROM messages m2 
            WHERE m2.sender_id = u.id 
            AND m2.receiver_id = $user_id 
            AND m2.product_id = p.id 
            AND m2.is_read = 0) as unread_count,
           (SELECT m3.message FROM messages m3 
            WHERE ((m3.sender_id = u.id AND m3.receiver_id = $user_id)
                  OR (m3.sender_id = $user_id AND m3.receiver_id = u.id))
            AND m3.product_id = p.id
            ORDER BY m3.created_at DESC LIMIT 1) as last_message,
           (SELECT m3.created_at FROM messages m3 
            WHERE ((m3.sender_id = u.id AND m3.receiver_id = $user_id)
                  OR (m3.sender_id = $user_id AND m3.receiver_id = u.id))
            AND m3.product_id = p.id
            ORDER BY m3.created_at DESC LIMIT 1) as last_time
    FROM products p
    JOIN users u ON p.seller_id = u.id
    WHERE EXISTS (SELECT 1 FROM messages m 
                  WHERE (m.sender_id = $user_id OR m.receiver_id = $user_id)
                  AND m.product_id = p.id)
    GROUP BY p.id, u.id
    ORDER BY last_time DESC
";
$messages_result = mysqli_query($conn, $messages_query);

// Get orders
$rentals_query = "
    SELECT o.*, p.title, p.images, p.seller_id, u.name as seller_name,
           DATEDIFF(o.end_date, CURDATE()) as days_left
    FROM orders o
    JOIN products p ON o.product_id = p.id
    JOIN users u ON p.seller_id = u.id
    WHERE o.buyer_id = $user_id AND o.type = 'rent'
    ORDER BY 
        CASE 
            WHEN o.returned = FALSE AND o.status = 'confirmed' THEN 1
            ELSE 2
        END,
        o.created_at DESC
";
$rentals_result = mysqli_query($conn, $rentals_query);

$purchases_query = "
    SELECT o.*, p.title, p.images, p.seller_id, u.name as seller_name
    FROM orders o
    JOIN products p ON o.product_id = p.id
    JOIN users u ON p.seller_id = u.id
    WHERE o.buyer_id = $user_id AND o.type = 'buy'
    ORDER BY o.created_at DESC
";
$purchases_result = mysqli_query($conn, $purchases_query);

$page = isset($_GET['page']) ? $_GET['page'] : 'marketplace';

// For conversation view
$selected_seller = isset($_GET['seller_id']) ? (int)$_GET['seller_id'] : 0;
$selected_product = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;

// Get full conversation messages if selected
$conversation_messages = [];
$conversation_seller_name = '';
$conversation_product_title = '';
$conversation_product_image = '';
$conversation_product_stock = 0;
$conversation_low_stock_threshold = 3;

if ($selected_seller > 0 && $selected_product > 0) {
    $info_query = "
        SELECT u.name as seller_name, p.title as product_title, p.images, p.stock, p.low_stock_threshold
        FROM users u, products p
        WHERE u.id = $selected_seller AND p.id = $selected_product
    ";
    $info_result = mysqli_query($conn, $info_query);
    if ($info_result && mysqli_num_rows($info_result) > 0) {
        $info = mysqli_fetch_assoc($info_result);
        $conversation_seller_name = $info['seller_name'];
        $conversation_product_title = $info['product_title'];
        $conversation_product_image = json_decode($info['images'], true)[0] ?? '';
        $conversation_product_stock = $info['stock'];
        $conversation_low_stock_threshold = $info['low_stock_threshold'];
    }
    
    $conv_query = "
        SELECT m.*, u.name as sender_name
        FROM messages m
        JOIN users u ON m.sender_id = u.id
        WHERE ((m.sender_id = $user_id AND m.receiver_id = $selected_seller)
              OR (m.sender_id = $selected_seller AND m.receiver_id = $user_id))
              AND m.product_id = $selected_product
        ORDER BY m.created_at ASC
    ";
    $conv_result = mysqli_query($conn, $conv_query);
    while ($msg = mysqli_fetch_assoc($conv_result)) {
        $conversation_messages[] = $msg;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PropMart - Buyer Marketplace</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background: #f5f5f5; }
        
        /* Header - Matching Seller Side */
        .top-header {
            background: #1a2639;
            color: white;
            padding: 8px 0;
            font-size: 13px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }
        
        .top-header .container {
            display: flex;
            justify-content: space-between;
        }
        
        .top-header-links {
            display: flex;
            gap: 20px;
        }
        
        .top-header-links a {
            color: #cbd5e0;
            text-decoration: none;
            transition: color 0.2s;
        }
        
        .top-header-links a:hover {
            color: #ff6b6b;
        }
        
        .main-header {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .main-header .container {
            display: flex;
            align-items: center;
            gap: 30px;
        }
        
        .logo {
            font-size: 28px;
            font-weight: 700;
            text-decoration: none;
        }
        
        .logo-primary { color: #ff6b6b; }
        .logo-secondary { color: #4ecdc4; }
        
        .search-bar {
            flex: 1;
            display: flex;
            max-width: 600px;
            border: 2px solid #ff6b6b;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .search-bar input {
            flex: 1;
            padding: 12px 15px;
            border: none;
            outline: none;
            font-size: 14px;
        }
        
        .search-bar button {
            background: #ff6b6b;
            color: white;
            border: none;
            padding: 0 20px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.2s;
        }
        
        .search-bar button:hover {
            background: #ff5252;
        }
        
        .header-icons {
            display: flex;
            gap: 25px;
            align-items: center;
        }
        
        .header-icon {
            position: relative;
            color: #1a2639;
            text-decoration: none;
            font-size: 20px;
            transition: color 0.2s;
        }
        
        .header-icon:hover {
            color: #ff6b6b;
        }
        
        .header-icon span {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #ff6b6b;
            color: white;
            font-size: 11px;
            padding: 2px 6px;
            border-radius: 10px;
            font-weight: 600;
        }
        
        .user-dropdown {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            padding: 5px 10px;
            border-radius: 30px;
            transition: background 0.2s;
        }
        
        .user-dropdown:hover {
            background: #f8f9fa;
        }
        
        .user-avatar-small {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        /* Navigation - Matching Seller Side */
        .nav-bar {
            background: white;
            border-bottom: 1px solid #f0f0f0;
            padding: 12px 0;
        }
        
        .nav-bar .container {
            display: flex;
            gap: 25px;
        }
        
        .nav-link {
            color: #1a2639;
            text-decoration: none;
            font-weight: 500;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 8px 0;
            border-bottom: 2px solid transparent;
            transition: all 0.2s;
        }
        
        .nav-link:hover {
            color: #ff6b6b;
            border-bottom-color: #ff6b6b;
        }
        
        .nav-link.active {
            color: #ff6b6b;
            border-bottom-color: #ff6b6b;
        }
        
        .nav-badge {
            background: #ff6b6b;
            color: white;
            border-radius: 12px;
            padding: 2px 8px;
            font-size: 11px;
            margin-left: 5px;
        }
        
        /* Banner */
        .banner {
            background: linear-gradient(135deg, #ff6b6b 0%, #ff8e8e 100%);
            border-radius: 12px;
            padding: 40px;
            margin: 30px 0;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 15px rgba(255,107,107,0.2);
        }
        
        .banner h2 {
            font-size: 28px;
            margin-bottom: 10px;
            font-weight: 700;
        }
        
        .banner p {
            font-size: 16px;
            opacity: 0.95;
        }
        
        .banner-btn {
            background: white;
            color: #ff6b6b;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .banner-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(0,0,0,0.1);
        }
        
        /* Category Pills */
        .category-pills {
            display: flex;
            gap: 12px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }
        
        .category-pill {
            padding: 8px 20px;
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 30px;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .category-pill:hover {
            border-color: #ff6b6b;
            color: #ff6b6b;
        }
        
        .category-pill.active {
            background: #ff6b6b;
            color: white;
            border-color: #ff6b6b;
        }
        
        /* Filter Bar */
        .filter-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            background: white;
            padding: 15px 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        
        .filter-group {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .filter-btn {
            padding: 6px 15px;
            border: 1px solid #e0e0e0;
            background: white;
            border-radius: 20px;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .filter-btn:hover {
            border-color: #ff6b6b;
            color: #ff6b6b;
        }
        
        .filter-btn.active {
            background: #ff6b6b;
            color: white;
            border-color: #ff6b6b;
        }
        
        .sort-select {
            padding: 8px 15px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            font-size: 13px;
            outline: none;
            cursor: pointer;
        }
        
        .sort-select:focus {
            border-color: #ff6b6b;
        }
        
        /* Product Grid */
        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .product-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            transition: all 0.3s;
            position: relative;
            cursor: pointer;
            border: 1px solid #f0f0f0;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 24px rgba(0,0,0,0.1);
        }
        
        .product-image-container {
            position: relative;
            padding-top: 100%;
            background: #f8f8f8;
        }
        
        .product-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .product-badge {
            position: absolute;
            top: 10px;
            left: 10px;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            z-index: 2;
        }
        
        .badge-buy { background: #10b981; color: white; }
        .badge-rent { background: #f59e0b; color: white; }
        .badge-both { background: #4ecdc4; color: white; }
        
        .stock-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            z-index: 2;
        }
        
        .badge-in-stock { background: #10b981; color: white; }
        .badge-low-stock { background: #f97316; color: white; }
        .badge-out-of-stock { background: #ff6b6b; color: white; }
        
        .save-btn {
            position: absolute;
            bottom: 10px;
            right: 10px;
            background: white;
            border: none;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            z-index: 3;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
            color: #ff6b6b;
        }
        
        .save-btn:hover {
            transform: scale(1.1);
        }
        
        .save-btn.saved {
            color: #ff6b6b;
        }
        
        .product-info {
            padding: 16px;
        }
        
        .product-title {
            font-size: 15px;
            font-weight: 600;
            color: #1a2639;
            margin-bottom: 8px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .product-rating {
            display: flex;
            align-items: center;
            gap: 4px;
            margin-bottom: 8px;
            font-size: 12px;
            color: #f59e0b;
        }
        
        .product-price {
            font-size: 18px;
            font-weight: 700;
            color: #ff6b6b;
            margin-bottom: 4px;
        }
        
        .product-price small {
            font-size: 12px;
            font-weight: 400;
            color: #718096;
        }
        
        .product-location {
            font-size: 12px;
            color: #718096;
            display: flex;
            align-items: center;
            gap: 4px;
            margin-bottom: 8px;
        }
        
        .product-seller {
            font-size: 12px;
            color: #718096;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        .verified-badge {
            color: #4ecdc4;
            font-size: 12px;
        }
        
        .product-stock-info {
            font-size: 12px;
            margin-bottom: 12px;
            padding: 4px 0;
        }
        
        .stock-in { color: #10b981; }
        .stock-low { color: #f97316; }
        .stock-out { color: #ff6b6b; }
        
        .product-actions {
            display: flex;
            gap: 8px;
            margin-top: 12px;
        }
        
        .btn {
            padding: 8px 12px;
            border: none;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
        }
        
        .btn-buy {
            background: #10b981;
            color: white;
        }
        
        .btn-buy:hover:not(:disabled) {
            background: #059669;
        }
        
        .btn-rent {
            background: #f59e0b;
            color: white;
        }
        
        .btn-rent:hover:not(:disabled) {
            background: #d97706;
        }
        
        .btn-cart {
            background: #4ecdc4;
            color: white;
        }
        
        .btn-cart:hover:not(:disabled) {
            background: #3db5ac;
        }
        
        .btn-chat {
            background: #667eea;
            color: white;
        }
        
        .btn-chat:hover {
            background: #5a67d8;
        }
        
        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        /* Section Headers */
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            margin-top: 30px;
        }
        
        .section-title {
            font-size: 20px;
            font-weight: 600;
            color: #1a2639;
        }
        
        .view-all {
            color: #ff6b6b;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
        }
        
        /* Cart Sidebar - Matching Seller Side */
        .cart-sidebar {
            position: fixed;
            right: 20px;
            top: 100px;
            width: 380px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            z-index: 99;
            display: none;
            border: 1px solid #f0f0f0;
        }
        
        .cart-sidebar.active {
            display: block;
            animation: slideIn 0.3s;
        }
        
        @keyframes slideIn {
            from { transform: translateX(100px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        .cart-header {
            padding: 20px;
            border-bottom: 1px solid #f0f0f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8fafc;
            border-radius: 16px 16px 0 0;
        }
        
        .cart-header h3 {
            font-size: 16px;
            color: #1a2639;
            font-weight: 600;
        }
        
        .cart-items {
            max-height: 400px;
            overflow-y: auto;
            padding: 15px;
        }
        
        .cart-item {
            display: flex;
            gap: 12px;
            padding: 12px;
            border-bottom: 1px solid #f0f0f0;
            transition: background 0.2s;
        }
        
        .cart-item:hover {
            background: #f8fafc;
        }
        
        .cart-item-img {
            width: 60px;
            height: 60px;
            border-radius: 8px;
            object-fit: cover;
        }
        
        .cart-item-info {
            flex: 1;
        }
        
        .cart-item-title {
            font-size: 13px;
            font-weight: 600;
            color: #1a2639;
            margin-bottom: 4px;
        }
        
        .cart-item-details {
            font-size: 11px;
            color: #718096;
            margin-bottom: 4px;
        }
        
        .cart-item-price {
            font-size: 14px;
            font-weight: 700;
            color: #ff6b6b;
        }
        
        .cart-item-remove {
            color: #a0aec0;
            cursor: pointer;
            transition: color 0.2s;
        }
        
        .cart-item-remove:hover {
            color: #ff6b6b;
        }
        
        .cart-footer {
            padding: 20px;
            border-top: 1px solid #f0f0f0;
            background: #f8fafc;
            border-radius: 0 0 16px 16px;
        }
        
        .cart-total {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
            font-weight: 600;
            font-size: 16px;
        }
        
        .btn-checkout {
            width: 100%;
            padding: 14px;
            background: #ff6b6b;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .btn-checkout:hover {
            background: #ff5252;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255,107,107,0.3);
        }
        
        /* Orders Grid */
        .orders-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
        }
        
        .order-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            border: 1px solid #f0f0f0;
        }
        
        .order-header {
            padding: 15px 20px;
            background: #f8fafc;
            border-bottom: 1px solid #f0f0f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .order-number {
            font-weight: 600;
            color: #1a2639;
        }
        
        .order-status {
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-pending { background: #fef3c7; color: #d97706; }
        .status-confirmed { background: #dbeafe; color: #2563eb; }
        .status-completed { background: #d1fae5; color: #059669; }
        .status-cancelled { background: #fee2e2; color: #dc2626; }
        
        .order-body {
            padding: 20px;
        }
        
        .order-product {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .order-product-img {
            width: 70px;
            height: 70px;
            border-radius: 8px;
            object-fit: cover;
        }
        
        .order-product-info h4 {
            font-size: 15px;
            color: #1a2639;
            margin-bottom: 4px;
        }
        
        .order-product-info p {
            font-size: 13px;
            color: #718096;
        }
        
        .order-details {
            margin: 15px 0;
            padding: 15px 0;
            border-top: 1px solid #f0f0f0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 13px;
        }
        
        .days-left {
            margin-top: 10px;
            padding: 8px 12px;
            background: #f8fafc;
            border-radius: 8px;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .days-left.warning {
            background: #fff0e6;
            color: #f97316;
        }
        
        .days-left.danger {
            background: #fee2e2;
            color: #dc2626;
        }
        
        /* Messages/Chat - Matching Seller Side */
        .messages-container {
            display: flex;
            gap: 20px;
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            height: calc(100vh - 250px);
            min-height: 500px;
            border: 1px solid #f0f0f0;
        }
        
        .conversations-list {
            width: 350px;
            border-right: 1px solid #f0f0f0;
            overflow-y: auto;
        }
        
        .conversation-item {
            display: flex;
            gap: 15px;
            padding: 20px;
            border-bottom: 1px solid #f0f0f0;
            cursor: pointer;
            transition: background 0.2s;
            text-decoration: none;
            color: inherit;
        }
        
        .conversation-item:hover {
            background: #f8fafc;
        }
        
        .conversation-item.active {
            background: #fff2f0;
            border-left: 4px solid #ff6b6b;
        }
        
        .conversation-item.unread {
            background: #fff8f0;
        }
        
        .conversation-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            object-fit: cover;
            background: #4ecdc4;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }
        
        .conversation-info {
            flex: 1;
        }
        
        .conversation-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 4px;
        }
        
        .conversation-name {
            font-weight: 600;
            color: #1a2639;
        }
        
        .conversation-time {
            font-size: 11px;
            color: #a0aec0;
        }
        
        .conversation-product {
            font-size: 12px;
            color: #ff6b6b;
            margin-bottom: 4px;
        }
        
        .conversation-preview {
            font-size: 13px;
            color: #718096;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .unread-badge {
            background: #ff6b6b;
            color: white;
            border-radius: 12px;
            padding: 2px 8px;
            font-size: 10px;
            margin-left: 8px;
        }
        
        .chat-area {
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        
        .chat-header {
            padding: 20px;
            border-bottom: 1px solid #f0f0f0;
            display: flex;
            gap: 15px;
            align-items: center;
            background: #f8fafc;
        }
        
        .chat-product-img {
            width: 50px;
            height: 50px;
            border-radius: 8px;
            object-fit: cover;
        }
        
        .chat-header-info h3 {
            font-size: 16px;
            margin-bottom: 4px;
            color: #1a2639;
        }
        
        .chat-header-info p {
            font-size: 13px;
            color: #718096;
        }
        
        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 15px;
            background: #f8fafc;
        }
        
        .message {
            max-width: 70%;
            padding: 12px 16px;
            border-radius: 15px;
            position: relative;
        }
        
        .message.received {
            align-self: flex-start;
            background: white;
            color: #1a2639;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        
        .message.sent {
            align-self: flex-end;
            background: #ff6b6b;
            color: white;
        }
        
        .message-time {
            font-size: 10px;
            margin-top: 6px;
            opacity: 0.7;
        }
        
        .chat-input {
            padding: 20px;
            border-top: 1px solid #f0f0f0;
            display: flex;
            gap: 10px;
            background: white;
        }
        
        .chat-input input {
            flex: 1;
            padding: 12px 15px;
            border: 2px solid #f0f0f0;
            border-radius: 25px;
            outline: none;
            transition: border-color 0.2s;
        }
        
        .chat-input input:focus {
            border-color: #ff6b6b;
        }
        
        .chat-input button {
            background: #ff6b6b;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s;
        }
        
        .chat-input button:hover {
            background: #ff5252;
            transform: translateY(-2px);
        }
        
        /* Modal */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }
        
        .modal-overlay.active {
            display: flex;
        }
        
        .modal {
            background: white;
            border-radius: 16px;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalSlideIn 0.3s;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
        }
        
        @keyframes modalSlideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        .modal-header {
            padding: 20px 24px;
            border-bottom: 1px solid #f0f0f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8fafc;
        }
        
        .modal-header h2 {
            font-size: 18px;
            color: #1a2639;
            font-weight: 600;
        }
        
        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #a0aec0;
            transition: color 0.2s;
        }
        
        .modal-close:hover {
            color: #ff6b6b;
        }
        
        .modal-body {
            padding: 24px;
        }
        
        .modal-footer {
            padding: 20px 24px;
            border-top: 1px solid #f0f0f0;
            display: flex;
            gap: 12px;
            justify-content: flex-end;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #1a2639;
            font-size: 14px;
        }
        
        .form-control {
            width: 100%;
            padding: 12px;
            border: 2px solid #f0f0f0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.2s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #ff6b6b;
        }
        
        .quantity-selector {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 15px 0;
        }
        
        .quantity-btn {
            width: 40px;
            height: 40px;
            border: 1px solid #f0f0f0;
            background: white;
            border-radius: 8px;
            cursor: pointer;
            font-size: 18px;
            transition: all 0.2s;
        }
        
        .quantity-btn:hover:not(:disabled) {
            background: #ff6b6b;
            color: white;
            border-color: #ff6b6b;
        }
        
        .quantity-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .quantity-input {
            width: 60px;
            text-align: center;
            padding: 8px;
            border: 2px solid #f0f0f0;
            border-radius: 8px;
            font-size: 14px;
        }
        
        .btn-success {
            background: #ff6b6b;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .btn-success:hover {
            background: #ff5252;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255,107,107,0.3);
        }
        
        .btn-cancel {
            background: #f0f0f0;
            color: #1a2639;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .btn-cancel:hover {
            background: #e0e0e0;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 12px;
        }
        
        .empty-state-icon {
            font-size: 64px;
            color: #cbd5e0;
            margin-bottom: 20px;
        }
        
        .empty-state h3 {
            font-size: 18px;
            color: #1a2639;
            margin-bottom: 8px;
        }
        
        .empty-state p {
            color: #718096;
        }
        
        /* Floating Cart Button */
        .floating-cart {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            background: #ff6b6b;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(255,107,107,0.3);
            z-index: 98;
            transition: all 0.2s;
        }
        
        .floating-cart:hover {
            transform: scale(1.1);
            background: #ff5252;
        }
        
        .floating-cart span {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #4ecdc4;
            color: white;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
        
        /* Loading Spinner */
        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #ff6b6b;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .search-bar {
                display: none;
            }
            
            .products-grid {
                grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
            }
            
            .cart-sidebar {
                width: 100%;
                right: 0;
                top: 0;
                height: 100vh;
                border-radius: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Top Header - Matching Seller Side -->
    <div class="top-header">
        <div class="container">
            <div class="top-header-links">
                <a href="#"><i class="fas fa-store"></i> Seller Centre</a>
                <a href="#"><i class="fas fa-download"></i> Download</a>
                <a href="#"><i class="fab fa-facebook"></i> <i class="fab fa-instagram"></i></a>
            </div>
            <div class="top-header-links">
                <a href="#"><i class="far fa-bell"></i> Notifications</a>
                <a href="#"><i class="far fa-question-circle"></i> Help</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>
    
    <!-- Main Header -->
    <div class="main-header">
        <div class="container">
            <a href="?page=marketplace" class="logo">
                <span class="logo-primary">Prop</span><span class="logo-secondary">Mart</span>
            </a>
            
            <div class="search-bar">
                <input type="text" placeholder="Search products, brands, and more...">
                <button><i class="fas fa-search"></i></button>
            </div>
            
            <div class="header-icons">
                <a href="#" class="header-icon" onclick="toggleCart()">
                    <i class="fas fa-shopping-cart"></i>
                    <?php if ($cart_items_count > 0): ?>
                        <span><?php echo $cart_items_count; ?></span>
                    <?php endif; ?>
                </a>
                <a href="?page=messages" class="header-icon">
                    <i class="far fa-comment"></i>
                    <?php if ($unread_count > 0): ?>
                        <span><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </a>
                <div class="user-dropdown">
                    <img src="<?php echo $user['avatar'] ?: 'https://via.placeholder.com/32'; ?>" class="user-avatar-small">
                    <span><?php echo explode(' ', $user['name'])[0]; ?></span>
                    <i class="fas fa-chevron-down"></i>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Navigation - Matching Seller Side -->
    <div class="nav-bar">
        <div class="container">
            <a href="?page=marketplace" class="nav-link <?php echo $page === 'marketplace' ? 'active' : ''; ?>">
                <i class="fas fa-home"></i> Home
            </a>
            <a href="?page=saved" class="nav-link <?php echo $page === 'saved' ? 'active' : ''; ?>">
                <i class="fas fa-heart"></i> Saved Items
            </a>
            <a href="?page=rentals" class="nav-link <?php echo $page === 'rentals' ? 'active' : ''; ?>">
                <i class="fas fa-calendar-alt"></i> My Rentals
            </a>
            <a href="?page=purchases" class="nav-link <?php echo $page === 'purchases' ? 'active' : ''; ?>">
                <i class="fas fa-box"></i> My Purchases
            </a>
            <a href="?page=messages" class="nav-link <?php echo $page === 'messages' ? 'active' : ''; ?>">
                <i class="far fa-comment"></i> Messages
                <?php if ($unread_count > 0): ?>
                    <span class="nav-badge"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
        </div>
    </div>

    <div class="container">
        <?php if ($page === 'marketplace'): ?>
            <!-- Welcome Banner -->
            <div class="banner">
                <div>
                    <h2>Welcome back, <?php echo explode(' ', $user['name'])[0]; ?>! 👋</h2>
                    <p>Discover amazing products available for purchase or rent</p>
                </div>
                <button class="banner-btn">Shop Now <i class="fas fa-arrow-right"></i></button>
            </div>
            
            <!-- Categories -->
            <div class="category-pills">
                <span class="category-pill active">All Categories</span>
                <span class="category-pill">Electronics</span>
                <span class="category-pill">Gaming</span>
                <span class="category-pill">Furniture</span>
                <span class="category-pill">Vehicles</span>
                <span class="category-pill">Tools</span>
                <span class="category-pill">Sports</span>
            </div>
            
            <!-- Filter Bar -->
            <div class="filter-bar">
                <div class="filter-group">
                    <span style="font-size: 14px; color: #718096;">Availability:</span>
                    <button class="filter-btn active" onclick="filterProducts('all')">All</button>
                    <button class="filter-btn" onclick="filterProducts('in-stock')">In Stock</button>
                    <button class="filter-btn" onclick="filterProducts('low-stock')">Low Stock</button>
                    <button class="filter-btn" onclick="filterProducts('out-of-stock')">Out of Stock</button>
                </div>
                <div>
                    <select class="sort-select">
                        <option>Sort by: Popular</option>
                        <option>Price: Low to High</option>
                        <option>Price: High to Low</option>
                        <option>Newest First</option>
                    </select>
                </div>
            </div>
            
            <!-- Product Grid -->
            <div class="products-grid" id="productsGrid">
                <?php 
                if ($products_result && mysqli_num_rows($products_result) > 0) {
                    while ($product = mysqli_fetch_assoc($products_result)): 
                        $images = json_decode($product['images'], true);
                        $badge_class = $product['type'] === 'buy' ? 'badge-buy' : ($product['type'] === 'rent' ? 'badge-rent' : 'badge-both');
                        $badge_text = $product['type'] === 'buy' ? 'For Sale' : ($product['type'] === 'rent' ? 'For Rent' : 'Sale & Rent');
                        
                        $stock_class = 'badge-in-stock';
                        $stock_text = 'In Stock';
                        if ($product['stock'] == 0) {
                            $stock_class = 'badge-out-of-stock';
                            $stock_text = 'Out of Stock';
                        } elseif ($product['stock'] <= $product['low_stock_threshold']) {
                            $stock_class = 'badge-low-stock';
                            $stock_text = 'Low Stock - ' . $product['stock'] . ' left';
                        }
                ?>
                        <div class="product-card" data-stock-status="<?php echo $product['stock_status']; ?>" onclick="viewProduct(<?php echo $product['id']; ?>)">
                            <div class="product-image-container">
                                <img class="product-image" src="<?php echo isset($images[0]) ? $images[0] : 'https://via.placeholder.com/200'; ?>" alt="">
                                <div class="product-badge <?php echo $badge_class; ?>"><?php echo $badge_text; ?></div>
                                <div class="stock-badge <?php echo $stock_class; ?>"><?php echo $stock_text; ?></div>
                                <button class="save-btn <?php echo $product['is_saved'] ? 'saved' : ''; ?>" 
                                        onclick="event.stopPropagation(); toggleSave(<?php echo $product['id']; ?>)">
                                    <i class="<?php echo $product['is_saved'] ? 'fas' : 'far'; ?> fa-heart"></i>
                                </button>
                            </div>
                            <div class="product-info">
                                <div class="product-title"><?php echo htmlspecialchars($product['title']); ?></div>
                                <div class="product-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star-half-alt"></i>
                                    <span style="color: #718096; margin-left: 4px;">(123)</span>
                                </div>
                                <div class="product-price">
                                    <?php if ($product['buy_price']): ?>
                                        ₱<?php echo number_format($product['buy_price']); ?>
                                    <?php endif; ?>
                                    <?php if ($product['rent_price'] && $product['buy_price']): ?>
                                        <small>or rent ₱<?php echo number_format($product['rent_price']); ?>/day</small>
                                    <?php elseif ($product['rent_price']): ?>
                                        ₱<?php echo number_format($product['rent_price']); ?>/day
                                    <?php endif; ?>
                                </div>
                                <div class="product-location">
                                    <i class="fas fa-map-marker-alt"></i> <?php echo $product['location']; ?>
                                </div>
                                <div class="product-seller">
                                    <i class="fas fa-store"></i> <?php echo htmlspecialchars($product['seller_name']); ?>
                                    <?php if ($product['seller_verified']): ?>
                                        <i class="fas fa-check-circle verified-badge"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="product-stock-info <?php echo $stock_class === 'badge-in-stock' ? 'stock-in' : ($stock_class === 'badge-low-stock' ? 'stock-low' : 'stock-out'); ?>">
                                    <i class="fas <?php echo $product['stock'] > 0 ? 'fa-check-circle' : 'fa-times-circle'; ?>"></i>
                                    <?php echo $product['stock']; ?> units available
                                </div>
                                <div class="product-actions">
                                    <?php if ($product['buy_price'] && $product['stock'] > 0): ?>
                                        <button class="btn btn-buy" onclick="event.stopPropagation(); openBuyModal(<?php echo $product['id']; ?>, '<?php echo addslashes($product['title']); ?>', <?php echo $product['buy_price']; ?>, <?php echo $product['stock']; ?>)">
                                            <i class="fas fa-shopping-cart"></i> Buy
                                        </button>
                                    <?php endif; ?>
                                    <?php if ($product['rent_price'] && $product['stock'] > 0): ?>
                                        <button class="btn btn-rent" onclick="event.stopPropagation(); openRentModal(<?php echo $product['id']; ?>, '<?php echo addslashes($product['title']); ?>', <?php echo $product['rent_price']; ?>, <?php echo $product['stock']; ?>)">
                                            <i class="fas fa-calendar-alt"></i> Rent
                                        </button>
                                    <?php endif; ?>
                                    <button class="btn btn-cart" onclick="event.stopPropagation(); addToCart(<?php echo $product['id']; ?>, '<?php echo $product['type']; ?>')">
                                        <i class="fas fa-cart-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; 
                } else {
                    echo '<div class="empty-state" style="grid-column: 1/-1;">
                        <div class="empty-state-icon">📦</div>
                        <h3>No products available</h3>
                        <p>Check back later for new listings</p>
                    </div>';
                }
                ?>
            </div>

        <?php elseif ($page === 'saved'): ?>
            <div class="section-header">
                <h2 class="section-title">My Saved Items</h2>
            </div>
            
            <?php if (mysqli_num_rows($saved_result) == 0): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">❤️</div>
                    <h3>No saved items yet</h3>
                    <p>Browse products and click the heart icon to save your favorites</p>
                </div>
            <?php else: ?>
                <div class="products-grid">
                    <?php while ($product = mysqli_fetch_assoc($saved_result)): 
                        $images = json_decode($product['images'], true);
                        
                        $stock_class = 'badge-in-stock';
                        $stock_text = 'In Stock';
                        if ($product['stock'] == 0) {
                            $stock_class = 'badge-out-of-stock';
                            $stock_text = 'Out of Stock';
                        } elseif ($product['stock'] <= $product['low_stock_threshold']) {
                            $stock_class = 'badge-low-stock';
                            $stock_text = 'Low Stock - ' . $product['stock'] . ' left';
                        }
                    ?>
                        <div class="product-card">
                            <div class="product-image-container">
                                <img class="product-image" src="<?php echo isset($images[0]) ? $images[0] : 'https://via.placeholder.com/200'; ?>" alt="">
                                <div class="stock-badge <?php echo $stock_class; ?>"><?php echo $stock_text; ?></div>
                                <button class="save-btn saved" onclick="toggleSave(<?php echo $product['id']; ?>)">
                                    <i class="fas fa-heart"></i>
                                </button>
                            </div>
                            <div class="product-info">
                                <div class="product-title"><?php echo htmlspecialchars($product['title']); ?></div>
                                <div class="product-price">
                                    <?php if ($product['buy_price']): ?>
                                        ₱<?php echo number_format($product['buy_price']); ?>
                                    <?php endif; ?>
                                </div>
                                <div class="product-location">
                                    <i class="fas fa-map-marker-alt"></i> <?php echo $product['location']; ?>
                                </div>
                                <div class="product-actions">
                                    <button class="btn btn-buy" onclick="openBuyModal(<?php echo $product['id']; ?>, '<?php echo addslashes($product['title']); ?>', <?php echo $product['buy_price']; ?>, <?php echo $product['stock']; ?>)">
                                        Buy Now
                                    </button>
                                    <button class="btn btn-cart" onclick="addToCart(<?php echo $product['id']; ?>, 'buy')">
                                        <i class="fas fa-cart-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>

        <?php elseif ($page === 'rentals'): ?>
            <div class="section-header">
                <h2 class="section-title">My Active Rentals</h2>
            </div>
            
            <?php if (mysqli_num_rows($rentals_result) == 0): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">🔑</div>
                    <h3>No active rentals</h3>
                    <p>Browse products and rent items you need</p>
                </div>
            <?php else: ?>
                <div class="orders-grid">
                    <?php while ($rental = mysqli_fetch_assoc($rentals_result)): 
                        $images = json_decode($rental['images'], true);
                        $days_left = $rental['days_left'];
                        $status_class = 'status-' . $rental['status'];
                        
                        $days_class = '';
                        if ($days_left < 0) {
                            $days_class = 'danger';
                        } elseif ($days_left <= 3) {
                            $days_class = 'warning';
                        }
                    ?>
                        <div class="order-card">
                            <div class="order-header">
                                <span class="order-number">#<?php echo $rental['order_number']; ?></span>
                                <span class="order-status <?php echo $status_class; ?>"><?php echo ucfirst($rental['status']); ?></span>
                            </div>
                            <div class="order-body">
                                <div class="order-product">
                                    <img src="<?php echo isset($images[0]) ? $images[0] : 'https://via.placeholder.com/70'; ?>" class="order-product-img">
                                    <div class="order-product-info">
                                        <h4><?php echo htmlspecialchars($rental['title']); ?></h4>
                                        <p>From: <?php echo htmlspecialchars($rental['seller_name']); ?></p>
                                    </div>
                                </div>
                                
                                <div class="order-details">
                                    <div class="detail-row">
                                        <span>Rental Period:</span>
                                        <span><?php echo $rental['start_date']; ?> to <?php echo $rental['end_date']; ?></span>
                                    </div>
                                    <div class="detail-row">
                                        <span>Amount:</span>
                                        <span style="font-weight: 600; color: #ff6b6b;">₱<?php echo number_format($rental['amount']); ?></span>
                                    </div>
                                    <div class="detail-row">
                                        <span>Quantity:</span>
                                        <span><?php echo $rental['quantity']; ?></span>
                                    </div>
                                </div>
                                
                                <?php if (!$rental['returned'] && $rental['status'] === 'confirmed'): ?>
                                    <div class="days-left <?php echo $days_class; ?>">
                                        <i class="fas fa-clock"></i>
                                        <?php if ($days_left >= 0): ?>
                                            <?php echo $days_left; ?> days remaining
                                        <?php else: ?>
                                            Overdue by <?php echo abs($days_left); ?> days
                                        <?php endif; ?>
                                    </div>
                                <?php elseif ($rental['returned']): ?>
                                    <div class="days-left" style="background: #d1fae5; color: #059669;">
                                        <i class="fas fa-check-circle"></i> Returned on <?php echo $rental['return_date']; ?>
                                    </div>
                                <?php endif; ?>
                                
                                <div style="margin-top: 15px;">
                                    <button class="btn btn-chat" style="width: 100%;" onclick="window.location.href='?page=messages&seller_id=<?php echo $rental['seller_id']; ?>&product_id=<?php echo $rental['product_id']; ?>'">
                                        <i class="far fa-comment"></i> Contact Seller
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>

        <?php elseif ($page === 'purchases'): ?>
            <div class="section-header">
                <h2 class="section-title">My Purchases</h2>
            </div>
            
            <?php if (mysqli_num_rows($purchases_result) == 0): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">🛒</div>
                    <h3>No purchases yet</h3>
                    <p>Start shopping to see your orders here</p>
                </div>
            <?php else: ?>
                <div class="orders-grid">
                    <?php while ($purchase = mysqli_fetch_assoc($purchases_result)): 
                        $images = json_decode($purchase['images'], true);
                        $status_class = 'status-' . $purchase['status'];
                    ?>
                        <div class="order-card">
                            <div class="order-header">
                                <span class="order-number">#<?php echo $purchase['order_number']; ?></span>
                                <span class="order-status <?php echo $status_class; ?>"><?php echo ucfirst($purchase['status']); ?></span>
                            </div>
                            <div class="order-body">
                                <div class="order-product">
                                    <img src="<?php echo isset($images[0]) ? $images[0] : 'https://via.placeholder.com/70'; ?>" class="order-product-img">
                                    <div class="order-product-info">
                                        <h4><?php echo htmlspecialchars($purchase['title']); ?></h4>
                                        <p>From: <?php echo htmlspecialchars($purchase['seller_name']); ?></p>
                                    </div>
                                </div>
                                
                                <div class="order-details">
                                    <div class="detail-row">
                                        <span>Amount:</span>
                                        <span style="font-weight: 600; color: #ff6b6b;">₱<?php echo number_format($purchase['amount']); ?></span>
                                    </div>
                                    <div class="detail-row">
                                        <span>Quantity:</span>
                                        <span><?php echo $purchase['quantity']; ?></span>
                                    </div>
                                    <div class="detail-row">
                                        <span>Purchase Date:</span>
                                        <span><?php echo date('M d, Y', strtotime($purchase['created_at'])); ?></span>
                                    </div>
                                </div>
                                
                                <div style="margin-top: 15px;">
                                    <button class="btn btn-chat" style="width: 100%;" onclick="window.location.href='?page=messages&seller_id=<?php echo $purchase['seller_id']; ?>&product_id=<?php echo $purchase['product_id']; ?>'">
                                        <i class="far fa-comment"></i> Contact Seller
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>

        <?php elseif ($page === 'messages'): ?>
            <div class="section-header">
                <h2 class="section-title">My Messages</h2>
            </div>
            
            <div class="messages-container">
                <div class="conversations-list">
                    <?php 
                    if ($messages_result && mysqli_num_rows($messages_result) > 0) {
                        while ($conv = mysqli_fetch_assoc($messages_result)): 
                            $active_class = ($selected_seller == $conv['seller_id'] && $selected_product == $conv['product_id']) ? 'active' : '';
                            $unread_class = ($conv['unread_count'] > 0) ? 'unread' : '';
                            $avatar_letter = strtoupper(substr($conv['seller_name'], 0, 1));
                    ?>
                            <a href="?page=messages&seller_id=<?php echo $conv['seller_id']; ?>&product_id=<?php echo $conv['product_id']; ?>" 
                               class="conversation-item <?php echo $active_class . ' ' . $unread_class; ?>">
                                <div class="conversation-avatar" style="background: <?php echo $conv['unread_count'] > 0 ? '#ff6b6b' : '#4ecdc4'; ?>;">
                                    <?php echo $avatar_letter; ?>
                                </div>
                                <div class="conversation-info">
                                    <div class="conversation-header">
                                        <span class="conversation-name"><?php echo htmlspecialchars($conv['seller_name']); ?></span>
                                        <span class="conversation-time">
                                            <?php echo $conv['last_time'] ? date('M d', strtotime($conv['last_time'])) : ''; ?>
                                        </span>
                                    </div>
                                    <div class="conversation-product">📦 <?php echo htmlspecialchars($conv['product_title']); ?></div>
                                    <div class="conversation-preview">
                                        <?php echo $conv['last_message'] ? htmlspecialchars(substr($conv['last_message'], 0, 50)) . '...' : 'No messages yet'; ?>
                                        <?php if ($conv['unread_count'] > 0): ?>
                                            <span class="unread-badge"><?php echo $conv['unread_count']; ?> new</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </a>
                    <?php 
                        endwhile; 
                    } else {
                        echo '<div style="padding: 30px; text-align: center; color: #718096;">
                                <i class="far fa-comments" style="font-size: 48px; margin-bottom: 15px;"></i>
                                <p>No messages yet. Start a conversation by clicking the chat button on a product!</p>
                              </div>';
                    }
                    ?>
                </div>
                
                <div class="chat-area">
                    <?php if (!empty($conversation_messages)): ?>
                        <div class="chat-header">
                            <img src="<?php echo $conversation_product_image ?: 'https://via.placeholder.com/50'; ?>" class="chat-product-img">
                            <div class="chat-header-info">
                                <h3><?php echo htmlspecialchars($conversation_product_title); ?></h3>
                                <p>Chat with <?php echo htmlspecialchars($conversation_seller_name); ?></p>
                            </div>
                        </div>
                        
                        <div class="chat-messages" id="chatMessages">
                            <?php foreach ($conversation_messages as $msg): 
                                $is_me = ($msg['sender_id'] == $user_id);
                            ?>
                                <div class="message <?php echo $is_me ? 'sent' : 'received'; ?>">
                                    <?php echo nl2br(htmlspecialchars($msg['message'])); ?>
                                    <div class="message-time">
                                        <?php echo date('M d, h:i A', strtotime($msg['created_at'])); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="chat-input">
                            <input type="text" id="replyMessage" placeholder="Type your message...">
                            <button onclick="sendReply(<?php echo $selected_seller; ?>, <?php echo $selected_product; ?>)">
                                <i class="fas fa-paper-plane"></i> Send
                            </button>
                        </div>
                        
                    <?php else: ?>
                        <div class="empty-state" style="height: 100%; display: flex; flex-direction: column; justify-content: center;">
                            <div class="empty-state-icon">💬</div>
                            <h3>Select a conversation</h3>
                            <p>Choose a conversation from the sidebar to start messaging</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Floating Cart Button -->
    <div class="floating-cart" onclick="toggleCart()">
        <i class="fas fa-shopping-cart"></i>
        <?php if ($cart_items_count > 0): ?>
            <span><?php echo $cart_items_count; ?></span>
        <?php endif; ?>
    </div>

    <!-- Cart Sidebar -->
    <div class="cart-sidebar" id="cartSidebar">
        <div class="cart-header">
            <h3>My Cart <span style="color: #718096; font-size: 13px;">(<?php echo $cart_items_count; ?> items)</span></h3>
            <i class="fas fa-times" style="cursor: pointer;" onclick="toggleCart()"></i>
        </div>
        
        <div class="cart-items" id="cartItems">
            <?php 
            $cart_total = 0;
            if ($cart_result && mysqli_num_rows($cart_result) > 0) {
                mysqli_data_seek($cart_result, 0);
                while ($item = mysqli_fetch_assoc($cart_result)): 
                    $images = json_decode($item['images'], true);
                    $price = $item['type'] === 'buy' ? $item['buy_price'] : $item['rent_price'];
                    $total = $price * $item['quantity'];
                    $cart_total += $total;
                    
                    // Calculate days for rental
                    $days = 1;
                    if ($item['type'] === 'rent' && $item['start_date'] && $item['end_date']) {
                        $start = new DateTime($item['start_date']);
                        $end = new DateTime($item['end_date']);
                        $days = $start->diff($end)->days + 1;
                        $total = $price * $days * $item['quantity'];
                    }
            ?>
                    <div class="cart-item" id="cart-item-<?php echo $item['id']; ?>">
                        <img src="<?php echo isset($images[0]) ? $images[0] : 'https://via.placeholder.com/60'; ?>" class="cart-item-img">
                        <div class="cart-item-info">
                            <div class="cart-item-title"><?php echo htmlspecialchars($item['title']); ?></div>
                            <div class="cart-item-details">
                                <?php echo $item['type'] === 'buy' ? 'Purchase' : 'Rental'; ?> · Qty: <?php echo $item['quantity']; ?>
                                <?php if ($item['type'] === 'rent' && $item['start_date']): ?>
                                    <br><?php echo $item['start_date']; ?> to <?php echo $item['end_date']; ?> (<?php echo $days; ?> days)
                                <?php endif; ?>
                            </div>
                            <div class="cart-item-price">₱<?php echo number_format($total); ?></div>
                        </div>
                        <div class="cart-item-remove" onclick="removeFromCart(<?php echo $item['id']; ?>)">
                            <i class="fas fa-trash"></i>
                        </div>
                    </div>
            <?php 
                endwhile;
            } else {
                echo '<div style="text-align: center; padding: 30px; color: #718096;">Your cart is empty</div>';
            }
            ?>
        </div>
        
        <?php if ($cart_items_count > 0): ?>
            <div class="cart-footer">
                <div class="cart-total">
                    <span>Total:</span>
                    <span style="color: #ff6b6b;">₱<?php echo number_format($cart_total); ?></span>
                </div>
                <button class="btn-checkout" onclick="checkoutCart()">Checkout</button>
            </div>
        <?php endif; ?>
    </div>

    <!-- Buy Modal -->
    <div class="modal-overlay" id="buyModal">
        <div class="modal">
            <div class="modal-header">
                <h2>Confirm Purchase</h2>
                <button class="modal-close" onclick="closeModal('buy')">&times;</button>
            </div>
            <div class="modal-body" id="buyModalContent">
                <!-- Dynamic content will be inserted here -->
            </div>
        </div>
    </div>

    <!-- Rent Modal -->
    <div class="modal-overlay" id="rentModal">
        <div class="modal">
            <div class="modal-header">
                <h2>Rental Details</h2>
                <button class="modal-close" onclick="closeModal('rent')">&times;</button>
            </div>
            <div class="modal-body" id="rentModalContent">
                <!-- Dynamic content will be inserted here -->
            </div>
        </div>
    </div>

    <script>
        let currentProductId = null;
        let currentProductTitle = '';
        let currentProductPrice = 0;
        let currentProductStock = 0;
        let currentQuantity = 1;
        let currentRentDays = 1;
        let currentRentStart = '';
        let currentRentEnd = '';

        function filterProducts(status) {
            const products = document.querySelectorAll('.product-card');
            const buttons = document.querySelectorAll('.filter-btn');
            
            buttons.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            products.forEach(product => {
                const productStatus = product.dataset.stockStatus;
                if (status === 'all' || productStatus === status) {
                    product.style.display = 'block';
                } else {
                    product.style.display = 'none';
                }
            });
        }

        function toggleSave(productId) {
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=toggle_save&product_id=' + productId
            })
            .then(response => response.json())
            .then(data => {
                const btn = event.target.closest('.save-btn');
                if (data.saved) {
                    btn.classList.add('saved');
                    btn.innerHTML = '<i class="fas fa-heart"></i>';
                } else {
                    btn.classList.remove('saved');
                    btn.innerHTML = '<i class="far fa-heart"></i>';
                }
            });
        }

        function addToCart(productId, type) {
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=add_to_cart&product_id=' + productId + '&type=' + type + '&quantity=1'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Added to cart!');
                    location.reload();
                } else {
                    alert('Item already in cart');
                }
            });
        }

        function removeFromCart(cartId) {
            if (confirm('Remove this item from cart?')) {
                fetch('', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=remove_from_cart&cart_id=' + cartId
                })
                .then(() => {
                    location.reload();
                });
            }
        }

        function toggleCart() {
            document.getElementById('cartSidebar').classList.toggle('active');
        }

        function openBuyModal(productId, title, price, stock) {
            currentProductId = productId;
            currentProductTitle = title;
            currentProductPrice = price;
            currentProductStock = stock;
            currentQuantity = 1;
            
            const modalContent = `
                <div>
                    <h3 style="margin-bottom: 15px; color: #1a2639;">${title}</h3>
                    
                    <div style="background: #f8fafc; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                            <span style="color: #718096;">Price:</span>
                            <span style="font-weight: 600; color: #ff6b6b;">₱${price.toLocaleString()}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span style="color: #718096;">Available Stock:</span>
                            <span style="color: #10b981;">${stock} units</span>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Quantity</label>
                        <div class="quantity-selector">
                            <button class="quantity-btn" onclick="decreaseQuantity()" ${stock <= 1 ? 'disabled' : ''}>-</button>
                            <input type="number" class="quantity-input" id="quantity" value="1" min="1" max="${stock}" readonly>
                            <button class="quantity-btn" onclick="increaseQuantity()" ${stock <= 1 ? 'disabled' : ''}>+</button>
                        </div>
                    </div>
                    
                    <div style="background: #fff2f0; padding: 15px; border-radius: 8px; margin-top: 20px;">
                        <div style="display: flex; justify-content: space-between; font-size: 16px;">
                            <span style="color: #1a2639;">Total:</span>
                            <span style="font-weight: 700; color: #ff6b6b;">₱<span id="totalPrice">${price.toLocaleString()}</span></span>
                        </div>
                    </div>
                    
                    <div style="display: flex; gap: 10px; margin-top: 20px;">
                        <button class="btn-success" style="flex: 1;" onclick="confirmPurchase()">Confirm Purchase</button>
                        <button class="btn-cancel" style="flex: 1;" onclick="closeModal('buy')">Cancel</button>
                    </div>
                </div>
            `;
            
            document.getElementById('buyModalContent').innerHTML = modalContent;
            document.getElementById('buyModal').classList.add('active');
        }

        function openRentModal(productId, title, price, stock) {
            currentProductId = productId;
            currentProductTitle = title;
            currentProductPrice = price;
            currentProductStock = stock;
            currentQuantity = 1;
            
            const today = new Date().toISOString().split('T')[0];
            const nextWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
            
            const modalContent = `
                <div>
                    <h3 style="margin-bottom: 15px; color: #1a2639;">${title}</h3>
                    
                    <div style="background: #f8fafc; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                            <span style="color: #718096;">Rent Price:</span>
                            <span style="font-weight: 600; color: #f59e0b;">₱${price.toLocaleString()}/day</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span style="color: #718096;">Available Stock:</span>
                            <span style="color: #10b981;">${stock} units</span>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Start Date</label>
                        <input type="date" id="startDate" class="form-control" value="${today}" min="${today}" onchange="updateRentTotal()">
                    </div>
                    
                    <div class="form-group">
                        <label>End Date</label>
                        <input type="date" id="endDate" class="form-control" value="${nextWeek}" min="${today}" onchange="updateRentTotal()">
                    </div>
                    
                    <div class="form-group">
                        <label>Quantity</label>
                        <div class="quantity-selector">
                            <button class="quantity-btn" onclick="decreaseRentQuantity()" ${stock <= 1 ? 'disabled' : ''}>-</button>
                            <input type="number" class="quantity-input" id="rentQuantity" value="1" min="1" max="${stock}" readonly>
                            <button class="quantity-btn" onclick="increaseRentQuantity()" ${stock <= 1 ? 'disabled' : ''}>+</button>
                        </div>
                    </div>
                    
                    <div style="background: #fff2f0; padding: 15px; border-radius: 8px; margin-top: 20px;">
                        <div style="display: flex; justify-content: space-between; font-size: 14px; margin-bottom: 8px;">
                            <span style="color: #1a2639;">Rental Period:</span>
                            <span style="color: #f59e0b;"><span id="rentalDays">7</span> days</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; font-size: 16px;">
                            <span style="color: #1a2639;">Total:</span>
                            <span style="font-weight: 700; color: #ff6b6b;">₱<span id="rentTotal">${(price * 7).toLocaleString()}</span></span>
                        </div>
                    </div>
                    
                    <div style="display: flex; gap: 10px; margin-top: 20px;">
                        <button class="btn-success" style="flex: 1;" onclick="confirmRent()">Confirm Rental</button>
                        <button class="btn-cancel" style="flex: 1;" onclick="closeModal('rent')">Cancel</button>
                    </div>
                </div>
            `;
            
            document.getElementById('rentModalContent').innerHTML = modalContent;
            document.getElementById('rentModal').classList.add('active');
        }

        function decreaseQuantity() {
            if (currentQuantity > 1) {
                currentQuantity--;
                document.getElementById('quantity').value = currentQuantity;
                updateTotal();
            }
        }

        function increaseQuantity() {
            if (currentQuantity < currentProductStock) {
                currentQuantity++;
                document.getElementById('quantity').value = currentQuantity;
                updateTotal();
            }
        }

        function updateTotal() {
            const total = currentProductPrice * currentQuantity;
            document.getElementById('totalPrice').textContent = total.toLocaleString();
        }

        function decreaseRentQuantity() {
            const qtyInput = document.getElementById('rentQuantity');
            let qty = parseInt(qtyInput.value);
            if (qty > 1) {
                qty--;
                qtyInput.value = qty;
                updateRentTotal();
            }
        }

        function increaseRentQuantity() {
            const qtyInput = document.getElementById('rentQuantity');
            let qty = parseInt(qtyInput.value);
            if (qty < currentProductStock) {
                qty++;
                qtyInput.value = qty;
                updateRentTotal();
            }
        }

        function updateRentTotal() {
            const start = new Date(document.getElementById('startDate').value);
            const end = new Date(document.getElementById('endDate').value);
            const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24)) + 1;
            const quantity = parseInt(document.getElementById('rentQuantity').value);
            const total = currentProductPrice * days * quantity;
            
            document.getElementById('rentalDays').textContent = days;
            document.getElementById('rentTotal').textContent = total.toLocaleString();
        }

        function confirmPurchase() {
            const total = currentProductPrice * currentQuantity;
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=create_order&product_id=' + currentProductId + '&type=buy&amount=' + total + '&quantity=' + currentQuantity
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Purchase confirmed! Order #: ' + data.order_number);
                    closeModal('buy');
                    window.location.href = '?page=purchases';
                } else {
                    alert('Error: ' + data.error);
                }
            });
        }

        function confirmRent() {
            const start = document.getElementById('startDate').value;
            const end = document.getElementById('endDate').value;
            const quantity = parseInt(document.getElementById('rentQuantity').value);
            const days = Math.ceil((new Date(end) - new Date(start)) / (1000 * 60 * 60 * 24)) + 1;
            const total = currentProductPrice * days * quantity;
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=create_order&product_id=' + currentProductId + '&type=rent&amount=' + total + 
                      '&quantity=' + quantity + '&start_date=' + start + '&end_date=' + end
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Rental confirmed! Order #: ' + data.order_number);
                    closeModal('rent');
                    window.location.href = '?page=rentals';
                } else {
                    alert('Error: ' + data.error);
                }
            });
        }

        function checkoutCart() {
            const items = [];
            document.querySelectorAll('.cart-item').forEach(item => {
                // Collect cart items data
                items.push({
                    product_id: item.id.replace('cart-item-', ''),
                    // Add other necessary data
                });
            });
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=checkout_cart&items=' + JSON.stringify(items)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Checkout successful!');
                    location.reload();
                }
            });
        }

        function sendReply(sellerId, productId) {
            const message = document.getElementById('replyMessage').value.trim();
            if (!message) return;
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=send_message&receiver_id=' + sellerId + '&product_id=' + productId + '&message=' + encodeURIComponent(message)
            })
            .then(response => response.json())
            .then(() => {
                const container = document.getElementById('chatMessages');
                const now = new Date();
                const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                
                const messageHtml = `
                    <div class="message sent">
                        ${message}
                        <div class="message-time">${timeStr}</div>
                    </div>
                `;
                
                container.innerHTML += messageHtml;
                document.getElementById('replyMessage').value = '';
                container.scrollTop = container.scrollHeight;
            });
        }

        function closeModal(type) {
            document.getElementById(type + 'Modal').classList.remove('active');
        }

        function viewProduct(productId) {
            // You can implement a product detail modal here
            console.log('View product:', productId);
        }

        // Scroll to bottom of messages
        window.onload = function() {
            const container = document.getElementById('chatMessages');
            if (container) {
                container.scrollTop = container.scrollHeight;
            }
        }

        // Close cart when clicking outside
        document.addEventListener('click', function(event) {
            const cart = document.getElementById('cartSidebar');
            const floatingCart = document.querySelector('.floating-cart');
            
            if (!cart.contains(event.target) && !floatingCart.contains(event.target) && cart.classList.contains('active')) {
                cart.classList.remove('active');
            }
        });
    </script>
</body>
</html>
<?php
echo "SHA1 hash for 'buyer123@': " . sha1('buyer123@') . "\n";
echo "SHA1 hash for 'seller##1': " . sha1('seller##1') . "\n";
?>
<?php
session_start();
require_once '../db_connect.php';

// Check if user is logged in and is seller
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'seller') {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Mark messages as read when viewing a conversation
if (isset($_GET['buyer_id']) && isset($_GET['product_id'])) {
    $buyer_id = (int)$_GET['buyer_id'];
    $product_id = (int)$_GET['product_id'];
    
    // Mark all messages in this conversation as read where receiver is current user
    $mark_read = "UPDATE messages SET is_read = 1 
                  WHERE sender_id = $buyer_id 
                  AND receiver_id = $user_id 
                  AND product_id = $product_id 
                  AND is_read = 0";
    mysqli_query($conn, $mark_read);
}

// Get user info
$query = "SELECT * FROM users WHERE id = $user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// Handle product creation/update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add_product') {
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $category = mysqli_real_escape_string($conn, $_POST['category']);
        $type = mysqli_real_escape_string($conn, $_POST['type']);
        $buy_price = !empty($_POST['buy_price']) ? (float)$_POST['buy_price'] : 'NULL';
        $rent_price = !empty($_POST['rent_price']) ? (float)$_POST['rent_price'] : 'NULL';
        $location = mysqli_real_escape_string($conn, $_POST['location']);
        $stock = (int)$_POST['stock'];
        $low_stock_threshold = (int)$_POST['low_stock_threshold'];
        $image = mysqli_real_escape_string($conn, $_POST['image']);
        $images = json_encode([$image]);
        
        $query = "INSERT INTO products (seller_id, title, description, category, type, buy_price, rent_price, location, stock, low_stock_threshold, images) 
                  VALUES ($user_id, '$title', '$description', '$category', '$type', $buy_price, $rent_price, '$location', $stock, $low_stock_threshold, '$images')";
        mysqli_query($conn, $query);
        
        $_SESSION['message'] = 'Product added successfully';
        header('Location: index.php?page=inventory');
        exit;
    }
    
    if ($_POST['action'] === 'update_product') {
        $product_id = (int)$_POST['product_id'];
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $category = mysqli_real_escape_string($conn, $_POST['category']);
        $type = mysqli_real_escape_string($conn, $_POST['type']);
        $buy_price = !empty($_POST['buy_price']) ? (float)$_POST['buy_price'] : 'NULL';
        $rent_price = !empty($_POST['rent_price']) ? (float)$_POST['rent_price'] : 'NULL';
        $location = mysqli_real_escape_string($conn, $_POST['location']);
        $stock = (int)$_POST['stock'];
        $low_stock_threshold = (int)$_POST['low_stock_threshold'];
        
        $query = "UPDATE products 
                  SET title='$title', description='$description', category='$category', type='$type', 
                      buy_price=$buy_price, rent_price=$rent_price, location='$location', 
                      stock=$stock, low_stock_threshold=$low_stock_threshold
                  WHERE id=$product_id AND seller_id=$user_id";
        mysqli_query($conn, $query);
        
        $_SESSION['message'] = 'Product updated successfully';
        header('Location: index.php?page=inventory');
        exit;
    }
    
    if ($_POST['action'] === 'delete_product') {
        $product_id = (int)$_POST['product_id'];
        
        $query = "DELETE FROM products WHERE id=$product_id AND seller_id=$user_id";
        mysqli_query($conn, $query);
        
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($_POST['action'] === 'update_order') {
        $order_id = (int)$_POST['order_id'];
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        
        // Get order details first
        $order_query = "SELECT * FROM orders WHERE id = $order_id";
        $order_result = mysqli_query($conn, $order_query);
        $order = mysqli_fetch_assoc($order_result);
        
        if ($order) {
            // Start transaction
            mysqli_begin_transaction($conn);
            
            try {
                // Update order status
                $update = "UPDATE orders SET status='$status' WHERE id=$order_id AND seller_id=$user_id";
                mysqli_query($conn, $update);
                
                // If order is confirmed (purchase), decrease stock
                if ($status === 'confirmed' && $order['type'] === 'buy') {
                    $product_query = "UPDATE products SET stock = stock - {$order['quantity']} WHERE id = {$order['product_id']} AND seller_id = $user_id";
                    mysqli_query($conn, $product_query);
                }
                
                // If order is completed (rental return), increase stock
                if ($status === 'completed' && $order['type'] === 'rent') {
                    $return_date = date('Y-m-d');
                    $update_return = "UPDATE orders SET returned = TRUE, return_date = '$return_date' WHERE id = $order_id";
                    mysqli_query($conn, $update_return);
                    
                    $product_query = "UPDATE products SET stock = stock + {$order['quantity']} WHERE id = {$order['product_id']} AND seller_id = $user_id";
                    mysqli_query($conn, $product_query);
                }
                
                // If order is cancelled, restore stock
                if ($status === 'cancelled') {
                    if ($order['type'] === 'buy' && $order['status'] === 'confirmed') {
                        $product_query = "UPDATE products SET stock = stock + {$order['quantity']} WHERE id = {$order['product_id']} AND seller_id = $user_id";
                        mysqli_query($conn, $product_query);
                    }
                }
                
                mysqli_commit($conn);
                echo json_encode(['success' => true]);
            } catch (Exception $e) {
                mysqli_rollback($conn);
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
        }
        exit;
    }
    
    if ($_POST['action'] === 'return_rental') {
        $order_id = (int)$_POST['order_id'];
        
        // Get order details
        $order_query = "SELECT * FROM orders WHERE id = $order_id AND seller_id = $user_id AND type = 'rent' AND returned = FALSE";
        $order_result = mysqli_query($conn, $order_query);
        $order = mysqli_fetch_assoc($order_result);
        
        if ($order) {
            mysqli_begin_transaction($conn);
            
            try {
                $return_date = date('Y-m-d');
                $update = "UPDATE orders SET returned = TRUE, return_date = '$return_date', status = 'completed' WHERE id = $order_id";
                mysqli_query($conn, $update);
                
                $product_query = "UPDATE products SET stock = stock + {$order['quantity']} WHERE id = {$order['product_id']} AND seller_id = $user_id";
                mysqli_query($conn, $product_query);
                
                mysqli_commit($conn);
                echo json_encode(['success' => true]);
            } catch (Exception $e) {
                mysqli_rollback($conn);
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
        }
        exit;
    }
    
    if ($_POST['action'] === 'send_message') {
        $receiver_id = (int)$_POST['receiver_id'];
        $product_id = (int)$_POST['product_id'];
        $message = mysqli_real_escape_string($conn, $_POST['message']);
        
        $insert = "INSERT INTO messages (sender_id, receiver_id, product_id, message, is_read) 
                   VALUES ($user_id, $receiver_id, $product_id, '$message', 0)";
        mysqli_query($conn, $insert);
        
        // Create notification for buyer
        $notif_title = "New Message";
        $notif_message = "You have a new message from the seller";
        $notif = "INSERT INTO notifications (user_id, type, title, message) 
                  VALUES ($receiver_id, 'message', '$notif_title', '$notif_message')";
        mysqli_query($conn, $notif);
        
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($_POST['action'] === 'update_stock') {
        $product_id = (int)$_POST['product_id'];
        $stock = (int)$_POST['stock'];
        
        $query = "UPDATE products SET stock = $stock WHERE id = $product_id AND seller_id = $user_id";
        mysqli_query($conn, $query);
        
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($_POST['action'] === 'update_availability') {
        $product_id = (int)$_POST['product_id'];
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        
        $query = "UPDATE products SET status = '$status' WHERE id = $product_id AND seller_id = $user_id";
        mysqli_query($conn, $query);
        
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($_POST['action'] === 'request_payout') {
        $amount = (float)$_POST['amount'];
        $method = mysqli_real_escape_string($conn, $_POST['method']);
        
        $query = "INSERT INTO transactions (seller_id, type, amount, description, status) 
                  VALUES ($user_id, 'out', $amount, 'Payout request to $method', 'pending')";
        mysqli_query($conn, $query);
        
        echo json_encode(['success' => true]);
        exit;
    }
}

// Get products
$products_query = "SELECT * FROM products WHERE seller_id = $user_id ORDER BY created_at DESC";
$products_result = mysqli_query($conn, $products_query);
$products_count = $products_result ? mysqli_num_rows($products_result) : 0;

// Get products with low stock
$low_stock_query = "SELECT * FROM products WHERE seller_id = $user_id AND stock <= low_stock_threshold AND stock > 0";
$low_stock_result = mysqli_query($conn, $low_stock_query);
$low_stock_count = $low_stock_result ? mysqli_num_rows($low_stock_result) : 0;

// Get out of stock products
$out_of_stock_query = "SELECT * FROM products WHERE seller_id = $user_id AND stock = 0";
$out_of_stock_result = mysqli_query($conn, $out_of_stock_query);
$out_of_stock_count = $out_of_stock_result ? mysqli_num_rows($out_of_stock_result) : 0;

// Get orders
$orders_query = "
    SELECT o.*, p.title, p.images, u.name as buyer_name
    FROM orders o
    JOIN products p ON o.product_id = p.id
    JOIN users u ON o.buyer_id = u.id
    WHERE o.seller_id = $user_id
    ORDER BY o.created_at DESC
";
$orders_result = mysqli_query($conn, $orders_query);
$orders_count = $orders_result ? mysqli_num_rows($orders_result) : 0;

// Get active rentals (not returned yet)
$active_rentals_query = "
    SELECT o.*, p.title, p.images, u.name as buyer_name
    FROM orders o
    JOIN products p ON o.product_id = p.id
    JOIN users u ON o.buyer_id = u.id
    WHERE o.seller_id = $user_id AND o.type = 'rent' AND o.returned = FALSE AND o.status = 'confirmed'
    ORDER BY o.end_date ASC
";
$active_rentals_result = mysqli_query($conn, $active_rentals_query);

// Get messages grouped by buyer and product
$messages_query = "
    SELECT 
           p.id as product_id,
           p.title as product_title,
           p.images,
           p.stock,
           p.low_stock_threshold,
           u.id as buyer_id, 
           u.name as buyer_name, 
           u.avatar,
           (SELECT COUNT(*) FROM messages m2 
            WHERE m2.sender_id = u.id 
            AND m2.receiver_id = $user_id 
            AND m2.product_id = p.id 
            AND m2.is_read = 0) as unread_count,
           (SELECT m3.message FROM messages m3 
            WHERE ((m3.sender_id = u.id AND m3.receiver_id = $user_id)
                  OR (m3.sender_id = $user_id AND m3.receiver_id = u.id))
            AND m3.product_id = p.id
            ORDER BY m3.created_at DESC LIMIT 1) as last_message,
           (SELECT m3.created_at FROM messages m3 
            WHERE ((m3.sender_id = u.id AND m3.receiver_id = $user_id)
                  OR (m3.sender_id = $user_id AND m3.receiver_id = u.id))
            AND m3.product_id = p.id
            ORDER BY m3.created_at DESC LIMIT 1) as last_time
    FROM products p
    JOIN users u ON 1=1
    WHERE EXISTS (SELECT 1 FROM messages m 
                  WHERE ((m.sender_id = u.id AND m.receiver_id = $user_id)
                        OR (m.sender_id = $user_id AND m.receiver_id = u.id))
                  AND m.product_id = p.id)
    GROUP BY p.id, u.id
    ORDER BY last_time DESC
";
$messages_result = mysqli_query($conn, $messages_query);

// Get earnings
$earnings_query = "SELECT SUM(amount) as total FROM transactions WHERE seller_id = $user_id AND type = 'in' AND status = 'completed'";
$earnings_result = mysqli_query($conn, $earnings_query);
$earnings = $earnings_result ? mysqli_fetch_assoc($earnings_result) : ['total' => 0];

// Get pending payouts
$payouts_query = "SELECT SUM(amount) as total FROM transactions WHERE seller_id = $user_id AND type = 'out' AND status = 'pending'";
$payouts_result = mysqli_query($conn, $payouts_query);
$pending_payouts = $payouts_result ? mysqli_fetch_assoc($payouts_result) : ['total' => 0];

// Get transaction history
$transactions_query = "
    SELECT * FROM transactions 
    WHERE seller_id = $user_id 
    ORDER BY created_at DESC 
    LIMIT 10
";
$transactions_result = mysqli_query($conn, $transactions_query);

$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';

// For conversation view
$selected_buyer = isset($_GET['buyer_id']) ? (int)$_GET['buyer_id'] : 0;
$selected_product = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;

// Get full conversation messages if selected
$conversation_messages = [];
$conversation_buyer_name = '';
$conversation_product_title = '';
$conversation_product_image = '';
$conversation_product_stock = 0;

if ($selected_buyer > 0 && $selected_product > 0) {
    // Get buyer and product info
    $info_query = "
        SELECT u.name as buyer_name, p.title as product_title, p.images, p.stock
        FROM users u, products p
        WHERE u.id = $selected_buyer AND p.id = $selected_product
    ";
    $info_result = mysqli_query($conn, $info_query);
    if ($info_result && mysqli_num_rows($info_result) > 0) {
        $info = mysqli_fetch_assoc($info_result);
        $conversation_buyer_name = $info['buyer_name'];
        $conversation_product_title = $info['product_title'];
        $conversation_product_image = json_decode($info['images'], true)[0] ?? '';
        $conversation_product_stock = $info['stock'];
    }
    
    // Get messages
    $conv_query = "
        SELECT m.*, u.name as sender_name
        FROM messages m
        JOIN users u ON m.sender_id = u.id
        WHERE ((m.sender_id = $user_id AND m.receiver_id = $selected_buyer)
              OR (m.sender_id = $selected_buyer AND m.receiver_id = $user_id))
              AND m.product_id = $selected_product
        ORDER BY m.created_at ASC
    ";
    $conv_result = mysqli_query($conn, $conv_query);
    while ($msg = mysqli_fetch_assoc($conv_result)) {
        $conversation_messages[] = $msg;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Dashboard - PropMart</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
            background: #f8fafc;
            display: flex;
        }
        
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            box-shadow: 2px 0 20px rgba(0,0,0,0.05);
            overflow-y: auto;
            z-index: 100;
        }
        
        .sidebar-header {
            padding: 30px 20px;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .sidebar-logo {
            font-size: 24px;
            font-weight: 800;
            font-family: 'Playfair Display', serif;
        }
        
        .sidebar-logo .logo-primary { color: #10b981; }
        .sidebar-logo .logo-secondary { color: #f59e0b; }
        
        .seller-info {
            margin-top: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 12px;
        }
        
        .seller-name {
            font-weight: 700;
            color: #333;
        }
        
        .seller-email {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        
        .sidebar-nav {
            padding: 20px;
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            border-radius: 12px;
            color: #666;
            text-decoration: none;
            margin-bottom: 5px;
            transition: all 0.3s;
        }
        
        .nav-item:hover {
            background: #f0fdf4;
            color: #10b981;
        }
        
        .nav-item.active {
            background: #10b981;
            color: white;
        }
        
        .nav-icon {
            font-size: 20px;
        }
        
        .nav-text {
            flex: 1;
            font-weight: 500;
        }
        
        .nav-badge {
            background: #f44336;
            color: white;
            border-radius: 20px;
            padding: 2px 8px;
            font-size: 11px;
            font-weight: 600;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            min-height: 100vh;
        }
        
        .top-bar {
            background: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            position: sticky;
            top: 0;
            z-index: 90;
        }
        
        .page-title {
            font-size: 24px;
            font-weight: 700;
            color: #333;
        }
        
        .user-menu {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .logout-btn {
            background: #f44336;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 30px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }
        
        .container {
            padding: 30px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            cursor: pointer;
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        
        .stat-value {
            font-size: 32px;
            font-weight: 800;
            color: #10b981;
        }
        
        .stat-label {
            color: #666;
            font-size: 14px;
            margin-top: 5px;
        }
        
        .stat-warning {
            color: #f59e0b;
            font-size: 12px;
            margin-top: 5px;
        }
        
        .action-bar {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .action-btn {
            padding: 12px 25px;
            border: none;
            border-radius: 30px;
            font-weight: 600;
            cursor: pointer;
            background: #10b981;
            color: white;
        }
        
        .action-btn:hover {
            background: #059669;
        }
        
        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
        }
        
        .product-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            position: relative;
        }
        
        .product-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        
        .product-body { padding: 20px; }
        
        .product-title {
            font-size: 18px;
            font-weight: 700;
            color: #333;
            margin-bottom: 10px;
        }
        
        .product-price {
            font-size: 20px;
            font-weight: 700;
            color: #10b981;
            margin: 10px 0;
        }
        
        .availability-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-top: 5px;
        }
        
        .available { background: #d1fae5; color: #059669; }
        .low-stock { background: #fef3c7; color: #d97706; }
        .out-of-stock { background: #fee2e2; color: #dc2626; }
        
        .product-stock {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-top: 10px;
        }
        
        .stock-low {
            background: #fee2e2;
            color: #dc2626;
        }
        
        .stock-medium {
            background: #fef3c7;
            color: #d97706;
        }
        
        .stock-high {
            background: #d1fae5;
            color: #059669;
        }
        
        .product-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
        }
        
        .btn-edit { background: #f0f9ff; color: #0284c7; }
        .btn-edit:hover { background: #e0f2fe; }
        .btn-delete { background: #fee2e2; color: #dc2626; }
        .btn-delete:hover { background: #fecaca; }
        .btn-reply { background: #10b981; color: white; }
        .btn-reply:hover { background: #059669; }
        .btn-success { background: #10b981; color: white; }
        .btn-success:hover { background: #059669; }
        .btn-warning { background: #f59e0b; color: white; }
        .btn-warning:hover { background: #d97706; }
        .btn-return { background: #667eea; color: white; }
        .btn-return:hover { background: #5a67d8; }
        
        /* Inbox Styles */
        .inbox-container {
            display: flex;
            gap: 20px;
            height: calc(100vh - 200px);
            min-height: 500px;
        }
        
        .inbox-sidebar {
            width: 400px;
            background: white;
            border-radius: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            overflow-y: auto;
        }
        
        .inbox-conversation {
            flex: 1;
            background: white;
            border-radius: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            display: flex;
            flex-direction: column;
        }
        
        .conversation-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 20px;
            border-bottom: 1px solid #f0f0f0;
            cursor: pointer;
            transition: background 0.3s;
            text-decoration: none;
            color: inherit;
        }
        
        .conversation-item:hover { background: #f8f9fa; }
        .conversation-item.active { background: #e8f5e9; border-left: 4px solid #10b981; }
        .conversation-item.unread { background: #f0fdf4; }
        
        .buyer-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .conversation-info { flex: 1; }
        
        .conversation-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        
        .buyer-name {
            font-weight: 700;
            color: #333;
        }
        
        .product-name {
            font-size: 14px;
            color: #10b981;
            font-weight: 500;
            margin-top: 3px;
        }
        
        .conversation-time {
            font-size: 11px;
            color: #999;
        }
        
        .last-message {
            font-size: 13px;
            color: #666;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 200px;
            margin-top: 5px;
        }
        
        .stock-indicator {
            font-size: 11px;
            margin-top: 3px;
        }
        
        .unread-badge {
            background: #10b981;
            color: white;
            border-radius: 20px;
            padding: 2px 8px;
            font-size: 11px;
            font-weight: 600;
            margin-left: 10px;
        }
        
        /* Conversation View */
        .conversation-header-info {
            padding: 20px;
            border-bottom: 1px solid #f0f0f0;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .conversation-product-img {
            width: 60px;
            height: 60px;
            border-radius: 10px;
            object-fit: cover;
        }
        
        .conversation-details h3 {
            margin-bottom: 5px;
            font-size: 18px;
        }
        
        .conversation-details p {
            color: #666;
            font-size: 14px;
        }
        
        .product-availability {
            margin-top: 10px;
            font-size: 13px;
        }
        
        .messages-container {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .message-bubble {
            max-width: 70%;
            padding: 12px 16px;
            border-radius: 15px;
            position: relative;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
        }
        
        .message-bubble.received {
            align-self: flex-start;
            background: #f0f0f0;
            color: #333;
            border-bottom-left-radius: 5px;
        }
        
        .message-bubble.sent {
            align-self: flex-end;
            background: #10b981;
            color: white;
            border-bottom-right-radius: 5px;
        }
        
        .message-bubble.sent .message-time { color: rgba(255,255,255,0.8); }
        
        .message-time {
            font-size: 10px;
            margin-top: 8px;
            opacity: 0.7;
            text-align: right;
        }
        
        .reply-box {
            padding: 20px;
            border-top: 1px solid #f0f0f0;
            display: flex;
            gap: 10px;
        }
        
        .reply-box input {
            flex: 1;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
        }
        
        .reply-box input:focus { outline: none; border-color: #10b981; }
        
        /* Inventory Table */
        .inventory-table {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        
        .inventory-header {
            display: grid;
            grid-template-columns: 80px 2fr 1fr 1fr 1fr 1fr 1fr 120px;
            padding: 15px 20px;
            background: #f8f9fa;
            font-weight: 700;
            color: #666;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .inventory-row {
            display: grid;
            grid-template-columns: 80px 2fr 1fr 1fr 1fr 1fr 1fr 120px;
            padding: 15px 20px;
            align-items: center;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .inventory-row:hover { background: #f8f9fa; }
        
        .inventory-img {
            width: 60px;
            height: 60px;
            border-radius: 10px;
            object-fit: cover;
        }
        
        .inventory-title { font-weight: 600; color: #333; }
        
        .inventory-price { color: #10b981; font-weight: 700; }
        
        .inventory-stock {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .stock-input {
            width: 70px;
            padding: 5px;
            border: 1px solid #e0e0e0;
            border-radius: 5px;
            text-align: center;
        }
        
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-active { background: #d1fae5; color: #059669; }
        .status-inactive { background: #fee2e2; color: #dc2626; }
        
        /* Orders */
        .orders-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
        }
        
        .order-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .order-id {
            font-weight: 700;
            color: #333;
        }
        
        .order-status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
        }
        
        .status-pending { background: #fef3c7; color: #d97706; }
        .status-confirmed { background: #d1fae5; color: #059669; }
        .status-completed { background: #e0f2fe; color: #0284c7; }
        .status-cancelled { background: #fee2e2; color: #dc2626; }
        
        .order-details {
            margin: 15px 0;
            padding: 15px 0;
            border-top: 1px solid #f0f0f0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .order-detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
        }
        
        .return-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            background: #d1fae5;
            color: #059669;
        }
        
        /* Payment Cards */
        .payment-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .payment-card {
            background: white;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        
        .payment-card-title {
            font-size: 16px;
            font-weight: 600;
            color: #666;
            margin-bottom: 15px;
        }
        
        .payment-amount {
            font-size: 36px;
            font-weight: 800;
            color: #10b981;
            margin-bottom: 20px;
        }
        
        .payment-amount small {
            font-size: 14px;
            color: #999;
            font-weight: 400;
        }
        
        .transaction-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .transaction-item:last-child { border-bottom: none; }
        
        .transaction-info { flex: 1; }
        
        .transaction-desc {
            font-weight: 600;
            color: #333;
            margin-bottom: 3px;
        }
        
        .transaction-date {
            font-size: 12px;
            color: #999;
        }
        
        .transaction-amount {
            font-weight: 700;
        }
        
        .amount-in { color: #10b981; }
        .amount-out { color: #f44336; }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }
        
        .modal.active { display: flex; }
        
        .modal-content {
            background: white;
            border-radius: 20px;
            width: 90%;
            max-width: 600px;
            padding: 30px;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .form-group { margin-bottom: 20px; }
        
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
        }
        
        input, select, textarea {
            width: 100%;
            padding: 10px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
        }
        
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #10b981;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }
        
        .empty-state-icon {
            font-size: 48px;
            margin-bottom: 20px;
        }
        
        .stock-warning {
            background: #fef3c7;
            border-left: 4px solid #f59e0b;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <span class="logo-primary">Prop</span><span class="logo-secondary">Mart</span>
            </div>
            <div class="seller-info">
                <div class="seller-name"><?php echo htmlspecialchars($user['business_name'] ?? $user['name']); ?></div>
                <div class="seller-email"><?php echo htmlspecialchars($user['email']); ?></div>
            </div>
        </div>
        
        <div class="sidebar-nav">
            <a href="?page=dashboard" class="nav-item <?php echo $page === 'dashboard' ? 'active' : ''; ?>">
                <span class="nav-icon">📊</span>
                <span class="nav-text">Dashboard</span>
            </a>
            <a href="?page=inventory" class="nav-item <?php echo $page === 'inventory' ? 'active' : ''; ?>">
                <span class="nav-icon">📦</span>
                <span class="nav-text">Inventory</span>
                <?php if ($low_stock_count > 0): ?>
                    <span class="nav-badge"><?php echo $low_stock_count; ?> low</span>
                <?php endif; ?>
            </a>
            <a href="?page=orders" class="nav-item <?php echo $page === 'orders' ? 'active' : ''; ?>">
                <span class="nav-icon">📋</span>
                <span class="nav-text">Orders</span>
                <?php 
                $pending_orders = 0;
                if ($orders_result) {
                    mysqli_data_seek($orders_result, 0);
                    while ($order = mysqli_fetch_assoc($orders_result)) {
                        if ($order['status'] === 'pending') $pending_orders++;
                    }
                }
                if ($pending_orders > 0): ?>
                    <span class="nav-badge"><?php echo $pending_orders; ?></span>
                <?php endif; ?>
            </a>
            <a href="?page=messages" class="nav-item <?php echo $page === 'messages' ? 'active' : ''; ?>">
                <span class="nav-icon">💬</span>
                <span class="nav-text">Messages</span>
                <?php 
                $unread_messages = 0;
                if ($messages_result) {
                    mysqli_data_seek($messages_result, 0);
                    while ($conv = mysqli_fetch_assoc($messages_result)) {
                        $unread_messages += $conv['unread_count'];
                    }
                }
                if ($unread_messages > 0): ?>
                    <span class="nav-badge"><?php echo $unread_messages; ?></span>
                <?php endif; ?>
            </a>
            <a href="?page=payment" class="nav-item <?php echo $page === 'payment' ? 'active' : ''; ?>">
                <span class="nav-icon">💰</span>
                <span class="nav-text">Payment</span>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="top-bar">
            <h1 class="page-title">
                <?php 
                if ($page === 'dashboard') echo 'Dashboard';
                elseif ($page === 'inventory') echo 'Inventory Management';
                elseif ($page === 'orders') echo 'Order Management';
                elseif ($page === 'messages') echo 'Messages';
                elseif ($page === 'payment') echo 'Payment & Payouts';
                ?>
            </h1>
            <div class="user-menu">
                <a href="../logout.php" class="logout-btn">Logout</a>
            </div>
        </div>

        <div class="container">
            <?php if (isset($_SESSION['message'])): ?>
                <div style="background: #d1fae5; color: #059669; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                    <?php 
                    echo $_SESSION['message']; 
                    unset($_SESSION['message']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if ($low_stock_count > 0 && $page === 'dashboard'): ?>
                <div class="stock-warning">
                    <strong>⚠️ Low Stock Alert:</strong> You have <?php echo $low_stock_count; ?> product(s) with low stock. 
                    <a href="?page=inventory" style="color: #d97706; font-weight: 600;">View Inventory</a>
                </div>
            <?php endif; ?>

            <?php if ($page === 'dashboard'): ?>
                <div class="stats-grid">
                    <div class="stat-card" onclick="window.location.href='?page=inventory'">
                        <div class="stat-value"><?php echo $products_count; ?></div>
                        <div class="stat-label">Total Products</div>
                        <?php if ($low_stock_count > 0): ?>
                            <div class="stat-warning">⚠️ <?php echo $low_stock_count; ?> low stock</div>
                        <?php endif; ?>
                    </div>
                    <div class="stat-card" onclick="window.location.href='?page=orders'">
                        <div class="stat-value"><?php echo $orders_count; ?></div>
                        <div class="stat-label">Total Orders</div>
                        <?php if ($pending_orders > 0): ?>
                            <div class="stat-warning">⏳ <?php echo $pending_orders; ?> pending</div>
                        <?php endif; ?>
                    </div>
                    <div class="stat-card" onclick="window.location.href='?page=payment'">
                        <div class="stat-value">₱<?php echo number_format($earnings['total'] ?? 0); ?></div>
                        <div class="stat-label">Total Earnings</div>
                    </div>
                    <div class="stat-card" onclick="window.location.href='?page=messages'">
                        <div class="stat-value"><?php echo mysqli_num_rows($messages_result); ?></div>
                        <div class="stat-label">Conversations</div>
                        <?php if ($unread_messages > 0): ?>
                            <div class="stat-warning">💬 <?php echo $unread_messages; ?> unread</div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <h3 style="margin-bottom: 20px;">Recent Products</h3>
                <div class="products-grid">
                    <?php 
                    if ($products_result && mysqli_num_rows($products_result) > 0) {
                        $count = 0;
                        mysqli_data_seek($products_result, 0);
                        while ($product = mysqli_fetch_assoc($products_result)) {
                            if ($count >= 4) break;
                            $count++;
                            $images = json_decode($product['images'], true);
                            
                            // Determine availability status
                            $avail_class = 'available';
                            $avail_text = 'In Stock';
                            if ($product['stock'] == 0) {
                                $avail_class = 'out-of-stock';
                                $avail_text = 'Out of Stock';
                            } elseif ($product['stock'] <= $product['low_stock_threshold']) {
                                $avail_class = 'low-stock';
                                $avail_text = 'Low Stock';
                            }
                    ?>
                            <div class="product-card">
                                <img class="product-image" src="<?php echo isset($images[0]) ? $images[0] : ''; ?>" alt="">
                                <div class="product-body">
                                    <div class="product-title"><?php echo htmlspecialchars($product['title']); ?></div>
                                    <div class="product-price">
                                        <?php if ($product['buy_price']): ?>₱<?php echo number_format($product['buy_price']); ?><?php endif; ?>
                                    </div>
                                    <span class="availability-badge <?php echo $avail_class; ?>">
                                        <?php echo $avail_text; ?> (<?php echo $product['stock']; ?> left)
                                    </span>
                                </div>
                            </div>
                    <?php 
                        }
                    } else { 
                        echo '<div class="empty-state">No products yet. Go to Inventory to add products.</div>';
                    } 
                    ?>
                </div>

            <?php elseif ($page === 'inventory'): ?>
                <div class="action-bar">
                    <button class="action-btn" onclick="openAddProductModal()">➕ Add New Product</button>
                </div>
                
                <div class="inventory-table">
                    <div class="inventory-header">
                        <div>Image</div>
                        <div>Product</div>
                        <div>Price</div>
                        <div>Type</div>
                        <div>Stock</div>
                        <div>Status</div>
                        <div>Availability</div>
                        <div>Actions</div>
                    </div>
                    
                    <?php 
                    if ($products_result && mysqli_num_rows($products_result) > 0) {
                        mysqli_data_seek($products_result, 0);
                        while ($product = mysqli_fetch_assoc($products_result)) { 
                            $images = json_decode($product['images'], true);
                            
                            // Stock level class
                            $stock_class = 'stock-high';
                            if ($product['stock'] == 0) {
                                $stock_class = 'stock-low';
                            } elseif ($product['stock'] <= $product['low_stock_threshold']) {
                                $stock_class = 'stock-medium';
                            }
                            
                            // Availability text
                            $avail_text = 'In Stock';
                            if ($product['stock'] == 0) {
                                $avail_text = 'Out of Stock';
                            } elseif ($product['stock'] <= $product['low_stock_threshold']) {
                                $avail_text = 'Low Stock';
                            }
                    ?>
                            <div class="inventory-row">
                                <div>
                                    <img class="inventory-img" src="<?php echo isset($images[0]) ? $images[0] : ''; ?>" alt="">
                                </div>
                                <div class="inventory-title"><?php echo htmlspecialchars($product['title']); ?></div>
                                <div class="inventory-price">
                                    <?php 
                                    if ($product['buy_price']) echo '₱' . number_format($product['buy_price']);
                                    if ($product['rent_price']) echo '<br><small>₱' . number_format($product['rent_price']) . '/day</small>';
                                    ?>
                                </div>
                                <div><?php echo ucfirst($product['type']); ?></div>
                                <div class="inventory-stock">
                                    <input type="number" class="stock-input" value="<?php echo $product['stock']; ?>" 
                                           onchange="updateStock(<?php echo $product['id']; ?>, this.value)" min="0">
                                    <span class="product-stock <?php echo $stock_class; ?>">
                                        <?php echo $product['stock']; ?> left
                                    </span>
                                </div>
                                <div>
                                    <select class="status-badge <?php echo $product['status'] === 'active' ? 'status-active' : 'status-inactive'; ?>" 
                                            onchange="updateAvailability(<?php echo $product['id']; ?>, this.value)">
                                        <option value="active" <?php echo $product['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                                        <option value="inactive" <?php echo $product['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                    </select>
                                </div>
                                <div>
                                    <span class="availability-badge <?php 
                                        if ($product['stock'] == 0) echo 'out-of-stock';
                                        elseif ($product['stock'] <= $product['low_stock_threshold']) echo 'low-stock';
                                        else echo 'available';
                                    ?>">
                                        <?php echo $avail_text; ?>
                                    </span>
                                </div>
                                <div class="product-actions">
                                    <button class="btn btn-edit" onclick="editProduct(<?php echo $product['id']; ?>, 
                                        '<?php echo addslashes($product['title']); ?>', 
                                        '<?php echo addslashes($product['description']); ?>', 
                                        '<?php echo $product['category']; ?>', 
                                        '<?php echo $product['type']; ?>', 
                                        <?php echo $product['buy_price'] ?: 'null'; ?>, 
                                        <?php echo $product['rent_price'] ?: 'null'; ?>, 
                                        '<?php echo addslashes($product['location']); ?>', 
                                        <?php echo $product['stock']; ?>,
                                        <?php echo $product['low_stock_threshold']; ?>,
                                        '<?php echo isset($images[0]) ? addslashes($images[0]) : ''; ?>')">Edit</button>
                                    <button class="btn btn-delete" onclick="deleteProduct(<?php echo $product['id']; ?>)">Delete</button>
                                </div>
                            </div>
                    <?php 
                        }
                    } else { 
                        echo '<div class="empty-state">
                            <div class="empty-state-icon">📦</div>
                            <h3>No products yet</h3>
                            <p>Click the "Add New Product" button to start selling</p>
                        </div>';
                    } 
                    ?>
                </div>

            <?php elseif ($page === 'orders'): ?>
                <h3 style="margin-bottom: 20px;">Order Management</h3>
                
                <?php if (mysqli_num_rows($active_rentals_result) > 0): ?>
                    <div style="margin-bottom: 30px;">
                        <h4 style="margin-bottom: 15px;">Active Rentals</h4>
                        <div class="orders-grid">
                            <?php while ($rental = mysqli_fetch_assoc($active_rentals_result)): 
                                $images = json_decode($rental['images'], true);
                                $days_left = ceil((strtotime($rental['end_date']) - time()) / (60 * 60 * 24));
                            ?>
                                <div class="order-card">
                                    <div class="order-header">
                                        <span class="order-id">Rental #<?php echo $rental['id']; ?></span>
                                        <span class="order-status status-confirmed">Active</span>
                                    </div>
                                    
                                    <div style="display: flex; gap: 15px;">
                                        <img src="<?php echo isset($images[0]) ? $images[0] : ''; ?>" style="width: 60px; height: 60px; border-radius: 10px; object-fit: cover;">
                                        <div>
                                            <div style="font-weight: 600;"><?php echo htmlspecialchars($rental['title']); ?></div>
                                            <div>Rented by: <?php echo htmlspecialchars($rental['buyer_name']); ?></div>
                                            <div>Due: <?php echo $rental['end_date']; ?> (<?php echo $days_left; ?> days left)</div>
                                        </div>
                                    </div>
                                    
                                    <div style="margin-top: 15px;">
                                        <button class="btn btn-return" onclick="returnRental(<?php echo $rental['id']; ?>)">
                                            ✓ Mark as Returned
                                        </button>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <h4 style="margin-bottom: 15px;">All Orders</h4>
                <?php 
                if ($orders_result && mysqli_num_rows($orders_result) > 0) {
                    mysqli_data_seek($orders_result, 0);
                    while ($order = mysqli_fetch_assoc($orders_result)) { 
                        $images = json_decode($order['images'], true);
                        $status_class = 'status-' . $order['status'];
                ?>
                        <div class="order-card">
                            <div class="order-header">
                                <span class="order-id">Order #<?php echo $order['order_number']; ?></span>
                                <span class="order-status <?php echo $status_class; ?>"><?php echo ucfirst($order['status']); ?></span>
                            </div>
                            
                            <div style="display: flex; gap: 15px;">
                                <img src="<?php echo isset($images[0]) ? $images[0] : ''; ?>" style="width: 60px; height: 60px; border-radius: 10px; object-fit: cover;">
                                <div>
                                    <div style="font-weight: 600;"><?php echo htmlspecialchars($order['title']); ?></div>
                                    <div>Buyer: <?php echo htmlspecialchars($order['buyer_name']); ?></div>
                                    <div>Amount: ₱<?php echo number_format($order['amount']); ?></div>
                                    <div>Quantity: <?php echo $order['quantity']; ?></div>
                                    <?php if ($order['type'] === 'rent'): ?>
                                        <div>Rental: <?php echo $order['start_date']; ?> to <?php echo $order['end_date']; ?></div>
                                        <?php if ($order['returned']): ?>
                                            <div><span class="return-badge">Returned on <?php echo $order['return_date']; ?></span></div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="order-details">
                                <div class="order-detail-row">
                                    <span>Type:</span>
                                    <span><?php echo ucfirst($order['type']); ?></span>
                                </div>
                                <div class="order-detail-row">
                                    <span>Payment Status:</span>
                                    <span><?php echo ucfirst($order['payment_status']); ?></span>
                                </div>
                            </div>
                            
                            <?php if ($order['status'] === 'pending'): ?>
                                <div style="margin-top: 15px; display: flex; gap: 10px;">
                                    <button class="btn btn-success" onclick="updateOrder(<?php echo $order['id']; ?>, 'confirmed')">✓ Accept</button>
                                    <button class="btn btn-delete" onclick="updateOrder(<?php echo $order['id']; ?>, 'cancelled')">✕ Reject</button>
                                </div>
                            <?php endif; ?>
                            <?php if ($order['status'] === 'confirmed' && $order['type'] === 'rent' && !$order['returned']): ?>
                                <div style="margin-top: 15px;">
                                    <button class="btn btn-return" onclick="returnRental(<?php echo $order['id']; ?>)">
                                        ✓ Mark as Returned
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php 
                    }
                } else { 
                    echo '<div class="empty-state">
                        <div class="empty-state-icon">📋</div>
                        <h3>No orders yet</h3>
                        <p>When customers place orders, they will appear here</p>
                    </div>';
                } 
                ?>

            <?php elseif ($page === 'messages'): ?>
                <div class="inbox-container">
                    <!-- Sidebar with conversations grouped by buyer and product -->
                    <div class="inbox-sidebar">
                        <?php 
                        if ($messages_result && mysqli_num_rows($messages_result) > 0) {
                            mysqli_data_seek($messages_result, 0);
                            while ($conv = mysqli_fetch_assoc($messages_result)): 
                                $active_class = ($selected_buyer == $conv['buyer_id'] && $selected_product == $conv['product_id']) ? 'active' : '';
                                $unread_class = ($conv['unread_count'] > 0) ? 'unread' : '';
                                $product_image = json_decode($conv['images'], true)[0] ?? '';
                                
                                // Determine stock status for display
                                $stock_status = '';
                                if ($conv['stock'] == 0) {
                                    $stock_status = '<span style="color: #dc2626; font-size: 11px;">(Out of Stock)</span>';
                                } elseif ($conv['stock'] <= $conv['low_stock_threshold']) {
                                    $stock_status = '<span style="color: #d97706; font-size: 11px;">(Low Stock)</span>';
                                }
                        ?>
                                <a href="?page=messages&buyer_id=<?php echo $conv['buyer_id']; ?>&product_id=<?php echo $conv['product_id']; ?>" 
                                   class="conversation-item <?php echo $active_class . ' ' . $unread_class; ?>">
                                    <img src="<?php echo $conv['avatar']; ?>" class="buyer-avatar" alt="">
                                    <div class="conversation-info">
                                        <div class="conversation-header">
                                            <span class="buyer-name"><?php echo htmlspecialchars($conv['buyer_name']); ?></span>
                                            <span class="conversation-time">
                                                <?php echo $conv['last_time'] ? date('M d', strtotime($conv['last_time'])) : ''; ?>
                                            </span>
                                        </div>
                                        <div class="product-name">
                                            📦 <?php echo htmlspecialchars($conv['product_title']); ?>
                                            <?php echo $stock_status; ?>
                                        </div>
                                        <div class="last-message">
                                            <?php echo $conv['last_message'] ? htmlspecialchars(substr($conv['last_message'], 0, 50)) . '...' : 'No messages yet'; ?>
                                            <?php if ($conv['unread_count'] > 0): ?>
                                                <span class="unread-badge"><?php echo $conv['unread_count']; ?> new</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </a>
                        <?php 
                            endwhile; 
                        } else {
                            echo '<div style="padding: 30px; text-align: center; color: #999;">
                                    No messages yet. When customers message you, they will appear here.
                                  </div>';
                        }
                        ?>
                    </div>
                    
                    <!-- Conversation View -->
                    <div class="inbox-conversation">
                        <?php if (!empty($conversation_messages)): ?>
                            <div class="conversation-header-info">
                                <img src="<?php echo $conversation_product_image; ?>" class="conversation-product-img" alt="">
                                <div class="conversation-details">
                                    <h3><?php echo htmlspecialchars($conversation_product_title); ?></h3>
                                    <p>Conversation with <?php echo htmlspecialchars($conversation_buyer_name); ?></p>
                                    <div class="product-availability">
                                        <?php 
                                        if ($conversation_product_stock == 0) {
                                            echo '<span style="color: #dc2626;">⚠️ Out of Stock</span>';
                                        } elseif ($conversation_product_stock <= 3) {
                                            echo '<span style="color: #d97706;">⚠️ Only ' . $conversation_product_stock . ' left in stock</span>';
                                        } else {
                                            echo '<span style="color: #10b981;">✅ ' . $conversation_product_stock . ' in stock</span>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="messages-container" id="messagesContainer">
                                <?php foreach ($conversation_messages as $msg): 
                                    $is_me = ($msg['sender_id'] == $user_id);
                                    $sender_label = $is_me ? 'You' : $conversation_buyer_name;
                                    $message_date = date('F j, Y', strtotime($msg['created_at']));
                                    $message_time = date('g:i a', strtotime($msg['created_at']));
                                ?>
                                    <div class="message-bubble <?php echo $is_me ? 'sent' : 'received'; ?>">
                                        <div style="font-weight: 600; margin-bottom: 5px; font-size: 12px;">
                                            <?php echo $sender_label; ?>
                                        </div>
                                        <?php echo nl2br(htmlspecialchars($msg['message'])); ?>
                                        <div class="message-time">
                                            <?php echo $message_date . ' at ' . $message_time; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            
                            <div class="reply-box">
                                <input type="text" id="replyMessage" placeholder="Type your reply..." 
                                       onkeypress="if(event.key === 'Enter') sendReply(<?php echo $selected_buyer; ?>, <?php echo $selected_product; ?>)">
                                <button class="btn btn-reply" onclick="sendReply(<?php echo $selected_buyer; ?>, <?php echo $selected_product; ?>)">
                                    Send
                                </button>
                            </div>
                            
                        <?php else: ?>
                            <div class="empty-state" style="height: 100%; display: flex; flex-direction: column; justify-content: center;">
                                <div class="empty-state-icon">💬</div>
                                <h3>Select a conversation</h3>
                                <p>Choose a conversation from the sidebar to view messages</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            <?php elseif ($page === 'payment'): ?>
                <div class="payment-grid">
                    <div class="payment-card">
                        <div class="payment-card-title">Available Balance</div>
                        <div class="payment-amount">₱<?php echo number_format(($earnings['total'] ?? 0) - ($pending_payouts['total'] ?? 0)); ?></div>
                        <button class="btn btn-success" onclick="openPayoutModal(<?php echo ($earnings['total'] ?? 0) - ($pending_payouts['total'] ?? 0); ?>)">Request Payout</button>
                    </div>
                    
                    <div class="payment-card">
                        <div class="payment-card-title">Total Earnings</div>
                        <div class="payment-amount">₱<?php echo number_format($earnings['total'] ?? 0); ?></div>
                        <div class="payment-card-title" style="margin-top: 20px;">Pending Payouts</div>
                        <div class="payment-amount" style="font-size: 24px; color: #f59e0b;">₱<?php echo number_format($pending_payouts['total'] ?? 0); ?></div>
                    </div>
                    
                    <div class="payment-card">
                        <div class="payment-card-title">Quick Stats</div>
                        <div style="margin-top: 15px;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                                <span>This Month:</span>
                                <span style="font-weight: 700; color: #10b981;">₱<?php echo number_format(($earnings['total'] ?? 0) * 0.3); ?></span>
                            </div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                                <span>Last Month:</span>
                                <span style="font-weight: 700;">₱<?php echo number_format(($earnings['total'] ?? 0) * 0.25); ?></span>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <span>Growth:</span>
                                <span style="font-weight: 700; color: #10b981;">+20%</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <h3 style="margin-bottom: 20px;">Recent Transactions</h3>
                <div class="inventory-table">
                    <?php 
                    if ($transactions_result && mysqli_num_rows($transactions_result) > 0) {
                        while ($trans = mysqli_fetch_assoc($transactions_result)) { 
                    ?>
                            <div class="transaction-item">
                                <div class="transaction-info">
                                    <div class="transaction-desc"><?php echo htmlspecialchars($trans['description']); ?></div>
                                    <div class="transaction-date"><?php echo date('F j, Y', strtotime($trans['created_at'])); ?></div>
                                </div>
                                <div class="transaction-amount <?php echo $trans['type'] === 'in' ? 'amount-in' : 'amount-out'; ?>">
                                    <?php echo $trans['type'] === 'in' ? '+' : '-'; ?>₱<?php echo number_format($trans['amount']); ?>
                                </div>
                                <div style="margin-left: 15px;">
                                    <span class="status-badge <?php echo $trans['status'] === 'completed' ? 'status-active' : 'status-pending'; ?>">
                                        <?php echo ucfirst($trans['status']); ?>
                                    </span>
                                </div>
                            </div>
                    <?php 
                        }
                    } else { 
                        echo '<div class="empty-state">No transactions yet</div>';
                    } 
                    ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Add/Edit Product Modal -->
    <div class="modal" id="productModal">
        <div class="modal-content">
            <h2 id="modalTitle">Add New Product</h2>
            
            <form method="POST">
                <input type="hidden" name="action" id="formAction" value="add_product">
                <input type="hidden" name="product_id" id="productId">
                
                <div class="form-group">
                    <label>Product Title</label>
                    <input type="text" name="title" id="title" required>
                </div>
                
                <div class="form-group">
                    <label>Category</label>
                    <select name="category" id="category" required>
                        <option value="electronics">Electronics</option>
                        <option value="gaming">Gaming</option>
                        <option value="furniture">Furniture</option>
                        <option value="vehicles">Vehicles</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Type</label>
                    <select name="type" id="type" required onchange="togglePriceFields()">
                        <option value="buy">For Sale Only</option>
                        <option value="rent">For Rent Only</option>
                        <option value="both">Both</option>
                    </select>
                </div>
                
                <div class="form-group" id="buyPriceGroup">
                    <label>Selling Price (₱)</label>
                    <input type="number" name="buy_price" id="buyPrice">
                </div>
                
                <div class="form-group" id="rentPriceGroup" style="display: none;">
                    <label>Rent Price (₱/day)</label>
                    <input type="number" name="rent_price" id="rentPrice">
                </div>
                
                <div class="form-group">
                    <label>Location</label>
                    <input type="text" name="location" id="location" required>
                </div>
                
                <div class="form-group">
                    <label>Initial Stock</label>
                    <input type="number" name="stock" id="stock" value="1" min="0">
                </div>
                
                <div class="form-group">
                    <label>Low Stock Threshold</label>
                    <input type="number" name="low_stock_threshold" id="lowStockThreshold" value="3" min="1">
                    <small style="color: #666;">You'll be alerted when stock reaches this number</small>
                </div>
                
                <div class="form-group">
                    <label>Image URL</label>
                    <input type="url" name="image" id="image" required>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" id="description" rows="4" required></textarea>
                </div>
                
                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="action-btn" style="flex: 1;">Save Product</button>
                    <button type="button" class="btn btn-delete" onclick="closeModal()" style="flex: 1;">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Payout Modal -->
    <div class="modal" id="payoutModal">
        <div class="modal-content">
            <h2>Request Payout</h2>
            
            <div style="background: #d1fae5; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                <div style="font-size: 14px; color: #059669; margin-bottom: 5px;">Available Balance</div>
                <div style="font-size: 32px; font-weight: 800; color: #10b981;" id="availableBalance">₱0</div>
            </div>
            
            <div class="form-group">
                <label>Amount to Withdraw</label>
                <input type="number" id="payoutAmount" placeholder="Enter amount" min="100">
            </div>
            
            <div class="form-group">
                <label>Payout Method</label>
                <select id="payoutMethod">
                    <option value="Bank Transfer">Bank Transfer (BDO ****1234)</option>
                    <option value="GCash">GCash (0917****5678)</option>
                    <option value="PayPal">PayPal (seller@email.com)</option>
                </select>
            </div>
            
            <div style="display: flex; gap: 10px;">
                <button class="btn btn-success" style="flex: 1;" onclick="requestPayout()">Confirm Withdrawal</button>
                <button class="btn btn-delete" style="flex: 1;" onclick="closePayoutModal()">Cancel</button>
            </div>
        </div>
    </div>

    <script>
        function togglePriceFields() {
            const type = document.getElementById('type').value;
            const buyGroup = document.getElementById('buyPriceGroup');
            const rentGroup = document.getElementById('rentPriceGroup');
            
            if (type === 'buy') {
                buyGroup.style.display = 'block';
                rentGroup.style.display = 'none';
            } else if (type === 'rent') {
                buyGroup.style.display = 'none';
                rentGroup.style.display = 'block';
            } else {
                buyGroup.style.display = 'block';
                rentGroup.style.display = 'block';
            }
        }

        function openAddProductModal() {
            document.getElementById('modalTitle').textContent = 'Add New Product';
            document.getElementById('formAction').value = 'add_product';
            document.getElementById('productId').value = '';
            document.getElementById('title').value = '';
            document.getElementById('category').value = 'electronics';
            document.getElementById('type').value = 'buy';
            document.getElementById('buyPrice').value = '';
            document.getElementById('rentPrice').value = '';
            document.getElementById('location').value = '';
            document.getElementById('stock').value = '1';
            document.getElementById('lowStockThreshold').value = '3';
            document.getElementById('image').value = '';
            document.getElementById('description').value = '';
            togglePriceFields();
            document.getElementById('productModal').classList.add('active');
        }

        function editProduct(id, title, description, category, type, buyPrice, rentPrice, location, stock, lowStockThreshold, image) {
            document.getElementById('modalTitle').textContent = 'Edit Product';
            document.getElementById('formAction').value = 'update_product';
            document.getElementById('productId').value = id;
            document.getElementById('title').value = title;
            document.getElementById('category').value = category;
            document.getElementById('type').value = type;
            document.getElementById('buyPrice').value = buyPrice === 'null' ? '' : buyPrice;
            document.getElementById('rentPrice').value = rentPrice === 'null' ? '' : rentPrice;
            document.getElementById('location').value = location;
            document.getElementById('stock').value = stock;
            document.getElementById('lowStockThreshold').value = lowStockThreshold;
            document.getElementById('image').value = image;
            document.getElementById('description').value = description;
            togglePriceFields();
            document.getElementById('productModal').classList.add('active');
        }

        function closeModal() {
            document.getElementById('productModal').classList.remove('active');
        }

        function deleteProduct(productId) {
            if (confirm('Are you sure you want to delete this product?')) {
                fetch('', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=delete_product&product_id=' + productId
                })
                .then(response => response.json())
                .then(() => {
                    location.reload();
                });
            }
        }

        function updateStock(productId, stock) {
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=update_stock&product_id=' + productId + '&stock=' + stock
            })
            .then(response => response.json())
            .then(() => {
                location.reload();
            });
        }

        function updateAvailability(productId, status) {
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=update_availability&product_id=' + productId + '&status=' + status
            })
            .then(response => response.json())
            .then(() => {
                location.reload();
            });
        }

        function updateOrder(orderId, status) {
            if (confirm('Are you sure you want to update this order?')) {
                fetch('', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=update_order&order_id=' + orderId + '&status=' + status
                })
                .then(response => response.json())
                .then(() => {
                    location.reload();
                });
            }
        }

        function returnRental(orderId) {
            if (confirm('Mark this rental as returned? The item will be added back to inventory.')) {
                fetch('', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=return_rental&order_id=' + orderId
                })
                .then(response => response.json())
                .then(() => {
                    location.reload();
                });
            }
        }

        function sendReply(buyerId, productId) {
            const message = document.getElementById('replyMessage').value.trim();
            if (!message) return;
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=send_message&receiver_id=' + buyerId + '&product_id=' + productId + '&message=' + encodeURIComponent(message)
            })
            .then(response => response.json())
            .then(() => {
                // Add message to UI
                const container = document.getElementById('messagesContainer');
                const now = new Date();
                const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                    'July', 'August', 'September', 'October', 'November', 'December'];
                const dateStr = monthNames[now.getMonth()] + ' ' + now.getDate() + ', ' + now.getFullYear();
                const hours = now.getHours();
                const minutes = now.getMinutes().toString().padStart(2, '0');
                const ampm = hours >= 12 ? 'pm' : 'am';
                const displayHours = hours % 12 || 12;
                const timeStr = displayHours + ':' + minutes + ' ' + ampm;
                
                const messageHtml = `
                    <div class="message-bubble sent">
                        <div style="font-weight: 600; margin-bottom: 5px; font-size: 12px;">You</div>
                        ${message}
                        <div class="message-time">${dateStr} at ${timeStr}</div>
                    </div>
                `;
                
                container.innerHTML += messageHtml;
                document.getElementById('replyMessage').value = '';
                container.scrollTop = container.scrollHeight;
            });
        }

        function openPayoutModal(balance) {
            document.getElementById('availableBalance').textContent = '₱' + balance.toLocaleString();
            document.getElementById('payoutModal').classList.add('active');
        }

        function closePayoutModal() {
            document.getElementById('payoutModal').classList.remove('active');
        }

        function requestPayout() {
            const amount = document.getElementById('payoutAmount').value;
            const method = document.getElementById('payoutMethod').value;
            
            if (!amount || amount < 100) {
                alert('Please enter a valid amount (minimum ₱100)');
                return;
            }
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=request_payout&amount=' + amount + '&method=' + encodeURIComponent(method)
            })
            .then(response => response.json())
            .then(() => {
                alert('Payout requested successfully!');
                closePayoutModal();
                location.reload();
            });
        }

        // Scroll to bottom of messages
        window.onload = function() {
            const container = document.getElementById('messagesContainer');
            if (container) {
                container.scrollTop = container.scrollHeight;
            }
        }
    </script>
</body>
</html>
<?php
session_start();
require_once '../db_connect.php';

// Check if user is logged in and is seller
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'seller') {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Mark messages as read when viewing a conversation
if (isset($_GET['buyer_id']) && isset($_GET['product_id'])) {
    $buyer_id = (int)$_GET['buyer_id'];
    $product_id = (int)$_GET['product_id'];
    
    // Mark all messages in this conversation as read where receiver is current user
    $mark_read = "UPDATE messages SET is_read = 1 
                  WHERE sender_id = $buyer_id 
                  AND receiver_id = $user_id 
                  AND product_id = $product_id 
                  AND is_read = 0";
    mysqli_query($conn, $mark_read);
}

// Get user info
$query = "SELECT * FROM users WHERE id = $user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// Handle product creation/update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add_product') {
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $category = mysqli_real_escape_string($conn, $_POST['category']);
        $type = mysqli_real_escape_string($conn, $_POST['type']);
        $buy_price = !empty($_POST['buy_price']) ? (float)$_POST['buy_price'] : 'NULL';
        $rent_price = !empty($_POST['rent_price']) ? (float)$_POST['rent_price'] : 'NULL';
        $location = mysqli_real_escape_string($conn, $_POST['location']);
        $stock = (int)$_POST['stock'];
        $low_stock_threshold = (int)$_POST['low_stock_threshold'];
        $image = mysqli_real_escape_string($conn, $_POST['image']);
        $images = json_encode([$image]);
        
        $query = "INSERT INTO products (seller_id, title, description, category, type, buy_price, rent_price, location, stock, low_stock_threshold, images) 
                  VALUES ($user_id, '$title', '$description', '$category', '$type', $buy_price, $rent_price, '$location', $stock, $low_stock_threshold, '$images')";
        mysqli_query($conn, $query);
        
        $_SESSION['message'] = 'Product added successfully';
        header('Location: index.php?page=inventory');
        exit;
    }
    
    if ($_POST['action'] === 'update_product') {
        $product_id = (int)$_POST['product_id'];
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $category = mysqli_real_escape_string($conn, $_POST['category']);
        $type = mysqli_real_escape_string($conn, $_POST['type']);
        $buy_price = !empty($_POST['buy_price']) ? (float)$_POST['buy_price'] : 'NULL';
        $rent_price = !empty($_POST['rent_price']) ? (float)$_POST['rent_price'] : 'NULL';
        $location = mysqli_real_escape_string($conn, $_POST['location']);
        $stock = (int)$_POST['stock'];
        $low_stock_threshold = (int)$_POST['low_stock_threshold'];
        
        $query = "UPDATE products 
                  SET title='$title', description='$description', category='$category', type='$type', 
                      buy_price=$buy_price, rent_price=$rent_price, location='$location', 
                      stock=$stock, low_stock_threshold=$low_stock_threshold
                  WHERE id=$product_id AND seller_id=$user_id";
        mysqli_query($conn, $query);
        
        $_SESSION['message'] = 'Product updated successfully';
        header('Location: index.php?page=inventory');
        exit;
    }
    
    if ($_POST['action'] === 'delete_product') {
        $product_id = (int)$_POST['product_id'];
        
        $query = "DELETE FROM products WHERE id=$product_id AND seller_id=$user_id";
        mysqli_query($conn, $query);
        
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($_POST['action'] === 'replenish_stock') {
        $product_id = (int)$_POST['product_id'];
        $quantity = (int)$_POST['quantity'];
        
        // Start transaction
        mysqli_begin_transaction($conn);
        
        try {
            // Update product stock
            $update = "UPDATE products SET stock = stock + $quantity WHERE id = $product_id AND seller_id = $user_id";
            mysqli_query($conn, $update);
            
            // Record replenishment
            $replenish_query = "INSERT INTO inventory_log (product_id, previous_stock, new_stock, change_type, notes, created_at) 
                               SELECT $product_id, stock - $quantity, stock, 'restock', 'Replenished $quantity units', NOW() 
                               FROM products WHERE id = $product_id";
            mysqli_query($conn, $replenish_query);
            
            mysqli_commit($conn);
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            mysqli_rollback($conn);
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }
    
    if ($_POST['action'] === 'update_order') {
        $order_id = (int)$_POST['order_id'];
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        
        // Get order details first
        $order_query = "SELECT * FROM orders WHERE id = $order_id";
        $order_result = mysqli_query($conn, $order_query);
        $order = mysqli_fetch_assoc($order_result);
        
        if ($order) {
            // Start transaction
            mysqli_begin_transaction($conn);
            
            try {
                // Update order status
                $update = "UPDATE orders SET status='$status' WHERE id=$order_id AND seller_id=$user_id";
                mysqli_query($conn, $update);
                
                // If order is confirmed (purchase), decrease stock
                if ($status === 'confirmed' && $order['type'] === 'buy') {
                    $product_query = "UPDATE products SET stock = stock - {$order['quantity']} WHERE id = {$order['product_id']} AND seller_id = $user_id";
                    mysqli_query($conn, $product_query);
                    
                    // Record sale
                    $sale_query = "INSERT INTO sales (order_id, product_id, seller_id, buyer_id, quantity, amount, sale_date) 
                                  VALUES ($order_id, {$order['product_id']}, $user_id, {$order['buyer_id']}, {$order['quantity']}, {$order['amount']}, NOW())";
                    mysqli_query($conn, $sale_query);
                }
                
                // If order is completed (rental return), increase stock
                if ($status === 'completed' && $order['type'] === 'rent') {
                    $return_date = date('Y-m-d');
                    $update_return = "UPDATE orders SET returned = TRUE, return_date = '$return_date' WHERE id = $order_id";
                    mysqli_query($conn, $update_return);
                    
                    $product_query = "UPDATE products SET stock = stock + {$order['quantity']} WHERE id = {$order['product_id']} AND seller_id = $user_id";
                    mysqli_query($conn, $product_query);
                }
                
                // If order is cancelled, restore stock
                if ($status === 'cancelled') {
                    if ($order['type'] === 'buy' && $order['status'] === 'confirmed') {
                        $product_query = "UPDATE products SET stock = stock + {$order['quantity']} WHERE id = {$order['product_id']} AND seller_id = $user_id";
                        mysqli_query($conn, $product_query);
                    }
                }
                
                mysqli_commit($conn);
                echo json_encode(['success' => true]);
            } catch (Exception $e) {
                mysqli_rollback($conn);
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
        }
        exit;
    }
    
    if ($_POST['action'] === 'return_rental') {
        $order_id = (int)$_POST['order_id'];
        
        // Get order details
        $order_query = "SELECT * FROM orders WHERE id = $order_id AND seller_id = $user_id AND type = 'rent' AND returned = FALSE";
        $order_result = mysqli_query($conn, $order_query);
        $order = mysqli_fetch_assoc($order_result);
        
        if ($order) {
            mysqli_begin_transaction($conn);
            
            try {
                $return_date = date('Y-m-d');
                $update = "UPDATE orders SET returned = TRUE, return_date = '$return_date', status = 'completed' WHERE id = $order_id";
                mysqli_query($conn, $update);
                
                $product_query = "UPDATE products SET stock = stock + {$order['quantity']} WHERE id = {$order['product_id']} AND seller_id = $user_id";
                mysqli_query($conn, $product_query);
                
                mysqli_commit($conn);
                echo json_encode(['success' => true]);
            } catch (Exception $e) {
                mysqli_rollback($conn);
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
        }
        exit;
    }
    
    if ($_POST['action'] === 'send_message') {
        $receiver_id = (int)$_POST['receiver_id'];
        $product_id = (int)$_POST['product_id'];
        $message = mysqli_real_escape_string($conn, $_POST['message']);
        
        $insert = "INSERT INTO messages (sender_id, receiver_id, product_id, message, is_read) 
                   VALUES ($user_id, $receiver_id, $product_id, '$message', 0)";
        mysqli_query($conn, $insert);
        
        // Create notification for buyer
        $notif_title = "New Message";
        $notif_message = "You have a new message from the seller";
        $notif = "INSERT INTO notifications (user_id, type, title, message) 
                  VALUES ($receiver_id, 'message', '$notif_title', '$notif_message')";
        mysqli_query($conn, $notif);
        
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($_POST['action'] === 'update_stock') {
        $product_id = (int)$_POST['product_id'];
        $stock = (int)$_POST['stock'];
        
        $query = "UPDATE products SET stock = $stock WHERE id = $product_id AND seller_id = $user_id";
        mysqli_query($conn, $query);
        
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($_POST['action'] === 'update_availability') {
        $product_id = (int)$_POST['product_id'];
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        
        $query = "UPDATE products SET status = '$status' WHERE id = $product_id AND seller_id = $user_id";
        mysqli_query($conn, $query);
        
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($_POST['action'] === 'request_payout') {
        $amount = (float)$_POST['amount'];
        $method = mysqli_real_escape_string($conn, $_POST['method']);
        
        $query = "INSERT INTO transactions (seller_id, type, amount, description, status) 
                  VALUES ($user_id, 'out', $amount, 'Payout request to $method', 'pending')";
        mysqli_query($conn, $query);
        
        echo json_encode(['success' => true]);
        exit;
    }
}

// Get products
$products_query = "SELECT * FROM products WHERE seller_id = $user_id ORDER BY created_at DESC";
$products_result = mysqli_query($conn, $products_query);
$products_count = $products_result ? mysqli_num_rows($products_result) : 0;

// Get products with low stock
$low_stock_query = "SELECT * FROM products WHERE seller_id = $user_id AND stock <= low_stock_threshold AND stock > 0";
$low_stock_result = mysqli_query($conn, $low_stock_query);
$low_stock_count = $low_stock_result ? mysqli_num_rows($low_stock_result) : 0;

// Get out of stock products
$out_of_stock_query = "SELECT * FROM products WHERE seller_id = $user_id AND stock = 0";
$out_of_stock_result = mysqli_query($conn, $out_of_stock_query);
$out_of_stock_count = $out_of_stock_result ? mysqli_num_rows($out_of_stock_result) : 0;

// Get orders
$orders_query = "
    SELECT o.*, p.title, p.images, u.name as buyer_name
    FROM orders o
    JOIN products p ON o.product_id = p.id
    JOIN users u ON o.buyer_id = u.id
    WHERE o.seller_id = $user_id
    ORDER BY o.created_at DESC
";
$orders_result = mysqli_query($conn, $orders_query);
$orders_count = $orders_result ? mysqli_num_rows($orders_result) : 0;

// Get active rentals (not returned yet)
$active_rentals_query = "
    SELECT o.*, p.title, p.images, u.name as buyer_name
    FROM orders o
    JOIN products p ON o.product_id = p.id
    JOIN users u ON o.buyer_id = u.id
    WHERE o.seller_id = $user_id AND o.type = 'rent' AND o.returned = FALSE AND o.status = 'confirmed'
    ORDER BY o.end_date ASC
";
$active_rentals_result = mysqli_query($conn, $active_rentals_query);

// Get messages grouped by buyer and product
$messages_query = "
    SELECT 
           p.id as product_id,
           p.title as product_title,
           p.images,
           p.stock,
           p.low_stock_threshold,
           u.id as buyer_id, 
           u.name as buyer_name, 
           u.avatar,
           (SELECT COUNT(*) FROM messages m2 
            WHERE m2.sender_id = u.id 
            AND m2.receiver_id = $user_id 
            AND m2.product_id = p.id 
            AND m2.is_read = 0) as unread_count,
           (SELECT m3.message FROM messages m3 
            WHERE ((m3.sender_id = u.id AND m3.receiver_id = $user_id)
                  OR (m3.sender_id = $user_id AND m3.receiver_id = u.id))
            AND m3.product_id = p.id
            ORDER BY m3.created_at DESC LIMIT 1) as last_message,
           (SELECT m3.created_at FROM messages m3 
            WHERE ((m3.sender_id = u.id AND m3.receiver_id = $user_id)
                  OR (m3.sender_id = $user_id AND m3.receiver_id = u.id))
            AND m3.product_id = p.id
            ORDER BY m3.created_at DESC LIMIT 1) as last_time
    FROM products p
    JOIN users u ON 1=1
    WHERE EXISTS (SELECT 1 FROM messages m 
                  WHERE ((m.sender_id = u.id AND m.receiver_id = $user_id)
                        OR (m.sender_id = $user_id AND m.receiver_id = u.id))
                  AND m.product_id = p.id)
    GROUP BY p.id, u.id
    ORDER BY last_time DESC
";
$messages_result = mysqli_query($conn, $messages_query);

// Get earnings
$earnings_query = "SELECT SUM(amount) as total FROM transactions WHERE seller_id = $user_id AND type = 'in' AND status = 'completed'";
$earnings_result = mysqli_query($conn, $earnings_query);
$earnings = $earnings_result ? mysqli_fetch_assoc($earnings_result) : ['total' => 0];

// Get pending payouts
$payouts_query = "SELECT SUM(amount) as total FROM transactions WHERE seller_id = $user_id AND type = 'out' AND status = 'pending'";
$payouts_result = mysqli_query($conn, $payouts_query);
$pending_payouts = $payouts_result ? mysqli_fetch_assoc($payouts_result) : ['total' => 0];

// Get transaction history
$transactions_query = "
    SELECT * FROM transactions 
    WHERE seller_id = $user_id 
    ORDER BY created_at DESC 
    LIMIT 10
";
$transactions_result = mysqli_query($conn, $transactions_query);

// Get sales data for reports
$sales_query = "
    SELECT 
        DATE(o.created_at) as sale_date,
        COUNT(*) as order_count,
        SUM(o.amount) as total_sales,
        SUM(CASE WHEN o.type = 'buy' THEN 1 ELSE 0 END) as buy_orders,
        SUM(CASE WHEN o.type = 'rent' THEN 1 ELSE 0 END) as rent_orders
    FROM orders o
    WHERE o.seller_id = $user_id AND o.status = 'completed'
    GROUP BY DATE(o.created_at)
    ORDER BY sale_date DESC
    LIMIT 30
";
$sales_result = mysqli_query($conn, $sales_query);

// Get inventory log (replenishment history)
$inventory_log_query = "
    SELECT il.*, p.title 
    FROM inventory_log il
    JOIN products p ON il.product_id = p.id
    WHERE p.seller_id = $user_id
    ORDER BY il.created_at DESC
    LIMIT 50
";
$inventory_log_result = mysqli_query($conn, $inventory_log_query);

$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
$tab = isset($_GET['tab']) ? $_GET['tab'] : 'all';

// For conversation view
$selected_buyer = isset($_GET['buyer_id']) ? (int)$_GET['buyer_id'] : 0;
$selected_product = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;

// Get full conversation messages if selected
$conversation_messages = [];
$conversation_buyer_name = '';
$conversation_product_title = '';
$conversation_product_image = '';
$conversation_product_stock = 0;

if ($selected_buyer > 0 && $selected_product > 0) {
    // Get buyer and product info
    $info_query = "
        SELECT u.name as buyer_name, p.title as product_title, p.images, p.stock
        FROM users u, products p
        WHERE u.id = $selected_buyer AND p.id = $selected_product
    ";
    $info_result = mysqli_query($conn, $info_query);
    if ($info_result && mysqli_num_rows($info_result) > 0) {
        $info = mysqli_fetch_assoc($info_result);
        $conversation_buyer_name = $info['buyer_name'];
        $conversation_product_title = $info['product_title'];
        $conversation_product_image = json_decode($info['images'], true)[0] ?? '';
        $conversation_product_stock = $info['stock'];
    }
    
    // Get messages
    $conv_query = "
        SELECT m.*, u.name as sender_name
        FROM messages m
        JOIN users u ON m.sender_id = u.id
        WHERE ((m.sender_id = $user_id AND m.receiver_id = $selected_buyer)
              OR (m.sender_id = $selected_buyer AND m.receiver_id = $user_id))
              AND m.product_id = $selected_product
        ORDER BY m.created_at ASC
    ";
    $conv_result = mysqli_query($conn, $conv_query);
    while ($msg = mysqli_fetch_assoc($conv_result)) {
        $conversation_messages[] = $msg;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Center - PropMart</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { background: #f5f5f5; display: flex; }
        
        /* Shopee/Lazada Inspired Sidebar */
        .sidebar {
            width: 260px;
            background: #1e293b;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            overflow-y: auto;
            z-index: 100;
            color: #fff;
        }
        
        .sidebar-header {
            padding: 30px 20px;
            border-bottom: 1px solid #334155;
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
        }
        
        .sidebar-logo {
            font-size: 26px;
            font-weight: 700;
        }
        
        .logo-primary { color: #ff6b6b; }
        .logo-secondary { color: #4ecdc4; }
        
        .seller-badge {
            margin-top: 15px;
            padding: 12px;
            background: rgba(255,255,255,0.1);
            border-radius: 8px;
        }
        
        .seller-name {
            font-weight: 600;
            font-size: 16px;
        }
        
        .seller-store {
            font-size: 13px;
            color: #94a3b8;
            margin-top: 4px;
        }
        
        .verification-badge {
            display: inline-block;
            background: #4ecdc4;
            color: #fff;
            font-size: 11px;
            padding: 2px 8px;
            border-radius: 12px;
            margin-top: 8px;
        }
        
        .sidebar-nav {
            padding: 20px 0;
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 14px 24px;
            color: #cbd5e1;
            text-decoration: none;
            transition: all 0.2s;
            border-left: 4px solid transparent;
        }
        
        .nav-item:hover {
            background: #334155;
            color: #fff;
            border-left-color: #ff6b6b;
        }
        
        .nav-item.active {
            background: #334155;
            color: #fff;
            border-left-color: #ff6b6b;
        }
        
        .nav-icon {
            font-size: 20px;
            width: 24px;
            text-align: center;
        }
        
        .nav-text {
            flex: 1;
            font-weight: 500;
            font-size: 15px;
        }
        
        .nav-badge {
            background: #ff6b6b;
            color: white;
            border-radius: 20px;
            padding: 2px 8px;
            font-size: 11px;
            font-weight: 600;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 260px;
            min-height: 100vh;
        }
        
        .top-bar {
            background: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            position: sticky;
            top: 0;
            z-index: 90;
        }
        
        .page-title {
            font-size: 22px;
            font-weight: 600;
            color: #1e293b;
        }
        
        .user-menu {
            display: flex;
            align-items: center;
            gap: 25px;
        }
        
        .notification-icon {
            position: relative;
            cursor: pointer;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #ff6b6b;
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 11px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #4ecdc4;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            cursor: pointer;
        }
        
        .logout-btn {
            background: #f1f5f9;
            color: #475569;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.2s;
        }
        
        .logout-btn:hover {
            background: #e2e8f0;
        }
        
        .container {
            padding: 30px;
        }
        
        /* Stats Cards - Shopee Style */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            cursor: pointer;
            transition: all 0.3s;
            border: 1px solid #f0f0f0;
        }
        
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            border-color: #4ecdc4;
        }
        
        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
        
        .stat-icon.blue { background: #e6f2ff; color: #3b82f6; }
        .stat-icon.green { background: #e6f7e6; color: #10b981; }
        .stat-icon.orange { background: #fff2e6; color: #f97316; }
        .stat-icon.red { background: #ffe6e6; color: #ef4444; }
        
        .stat-value {
            font-size: 28px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .stat-label {
            color: #64748b;
            font-size: 14px;
            margin-top: 5px;
        }
        
        .stat-trend {
            font-size: 12px;
            margin-top: 8px;
        }
        
        .trend-up { color: #10b981; }
        .trend-down { color: #ef4444; }
        
        /* Tabs */
        .tabs {
            display: flex;
            border-bottom: 2px solid #e2e8f0;
            margin-bottom: 25px;
            background: white;
            padding: 0 20px;
            border-radius: 8px 8px 0 0;
        }
        
        .tab {
            padding: 16px 24px;
            cursor: pointer;
            color: #64748b;
            font-weight: 500;
            position: relative;
            transition: all 0.2s;
        }
        
        .tab:hover {
            color: #ff6b6b;
        }
        
        .tab.active {
            color: #ff6b6b;
        }
        
        .tab.active::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            right: 0;
            height: 2px;
            background: #ff6b6b;
        }
        
        .tab-badge {
            background: #f1f5f9;
            color: #475569;
            border-radius: 16px;
            padding: 2px 8px;
            font-size: 11px;
            margin-left: 8px;
        }
        
        /* Product Grid - Shopee Style */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 20px;
        }
        
        .product-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            transition: all 0.3s;
            border: 1px solid #f0f0f0;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 24px rgba(0,0,0,0.1);
        }
        
        .product-image-container {
            position: relative;
            padding-top: 100%;
            background: #f8fafc;
        }
        
        .product-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .product-badge {
            position: absolute;
            top: 10px;
            left: 10px;
            background: #ff6b6b;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .product-type-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
        }
        
        .product-info {
            padding: 16px;
        }
        
        .product-title {
            font-size: 15px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 8px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .product-prices {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }
        
        .buy-price {
            color: #ff6b6b;
            font-weight: 700;
            font-size: 16px;
        }
        
        .rent-price {
            color: #4ecdc4;
            font-weight: 600;
            font-size: 14px;
        }
        
        .product-stock {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 12px;
        }
        
        .stock-bar {
            flex: 1;
            height: 6px;
            background: #e2e8f0;
            border-radius: 3px;
            overflow: hidden;
        }
        
        .stock-fill {
            height: 100%;
            background: #10b981;
            border-radius: 3px;
        }
        
        .stock-fill.low { background: #f97316; }
        .stock-fill.critical { background: #ef4444; }
        
        .stock-text {
            font-size: 12px;
            color: #64748b;
        }
        
        .product-actions {
            display: flex;
            gap: 8px;
            margin-top: 12px;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            font-size: 13px;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        
        .btn-primary {
            background: #ff6b6b;
            color: white;
        }
        
        .btn-primary:hover {
            background: #ff5252;
        }
        
        .btn-outline {
            background: white;
            border: 1px solid #e2e8f0;
            color: #475569;
        }
        
        .btn-outline:hover {
            border-color: #ff6b6b;
            color: #ff6b6b;
        }
        
        .btn-success {
            background: #10b981;
            color: white;
        }
        
        .btn-success:hover {
            background: #059669;
        }
        
        .btn-warning {
            background: #f97316;
            color: white;
        }
        
        .btn-warning:hover {
            background: #ea580c;
        }
        
        .btn-sm {
            padding: 4px 12px;
            font-size: 12px;
        }
        
        /* Table Styles */
        .table-container {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th {
            background: #f8fafc;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            color: #475569;
            font-size: 14px;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .table td {
            padding: 16px 20px;
            border-bottom: 1px solid #f1f5f9;
            color: #1e293b;
            font-size: 14px;
        }
        
        .table tr:hover td {
            background: #f8fafc;
        }
        
        .table-product {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .table-product-img {
            width: 48px;
            height: 48px;
            border-radius: 8px;
            object-fit: cover;
        }
        
        /* Status Badges */
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .badge-success { background: #d1fae5; color: #059669; }
        .badge-warning { background: #fef3c7; color: #d97706; }
        .badge-danger { background: #fee2e2; color: #dc2626; }
        .badge-info { background: #dbeafe; color: #2563eb; }
        .badge-purple { background: #ede9fe; color: #7c3aed; }
        
        /* Modal Styles */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }
        
        .modal-overlay.active {
            display: flex;
        }
        
        .modal {
            background: white;
            border-radius: 16px;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalSlideIn 0.3s;
        }
        
        @keyframes modalSlideIn {
            from { transform: translateY(-30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        .modal-header {
            padding: 20px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-header h2 {
            font-size: 20px;
            color: #1e293b;
        }
        
        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #94a3b8;
        }
        
        .modal-body {
            padding: 24px;
        }
        
        .modal-footer {
            padding: 16px 24px;
            border-top: 1px solid #e2e8f0;
            display: flex;
            gap: 12px;
            justify-content: flex-end;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #475569;
            font-size: 14px;
        }
        
        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #ff6b6b;
            box-shadow: 0 0 0 3px rgba(255,107,107,0.1);
        }
        
        .input-group {
            display: flex;
            gap: 10px;
        }
        
        /* Confirmation Modal */
        .confirm-modal {
            text-align: center;
        }
        
        .confirm-icon {
            font-size: 48px;
            color: #ff6b6b;
            margin-bottom: 16px;
        }
        
        .confirm-title {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 8px;
        }
        
        .confirm-message {
            color: #64748b;
            margin-bottom: 24px;
        }
        
        .confirm-actions {
            display: flex;
            gap: 12px;
            justify-content: center;
        }
        
        .btn-cancel {
            background: #f1f5f9;
            color: #475569;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 500;
            cursor: pointer;
        }
        
        .btn-confirm {
            background: #ff6b6b;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 500;
            cursor: pointer;
        }
        
        /* Reports Grid */
        .reports-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .report-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        
        .report-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .report-title {
            font-size: 16px;
            font-weight: 600;
            color: #1e293b;
        }
        
        .report-value {
            font-size: 32px;
            font-weight: 700;
            color: #ff6b6b;
        }
        
        .report-sub {
            color: #64748b;
            font-size: 14px;
            margin-top: 5px;
        }
        
        /* Inbox Styles */
        .inbox-container {
            display: flex;
            gap: 20px;
            height: calc(100vh - 200px);
            min-height: 500px;
        }
        
        .conversation-list {
            width: 380px;
            background: white;
            border-radius: 12px;
            overflow-y: auto;
            border: 1px solid #f0f0f0;
        }
        
        .conversation-item {
            display: flex;
            gap: 15px;
            padding: 20px;
            border-bottom: 1px solid #f0f0f0;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .conversation-item:hover {
            background: #f8fafc;
        }
        
        .conversation-item.active {
            background: #fff2f0;
            border-left: 4px solid #ff6b6b;
        }
        
        .conversation-item.unread {
            background: #fff8f0;
        }
        
        .conversation-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: #4ecdc4;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }
        
        .conversation-info {
            flex: 1;
        }
        
        .conversation-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        
        .conversation-name {
            font-weight: 600;
            color: #1e293b;
        }
        
        .conversation-time {
            font-size: 11px;
            color: #94a3b8;
        }
        
        .conversation-product {
            font-size: 12px;
            color: #ff6b6b;
            margin-bottom: 5px;
        }
        
        .conversation-preview {
            font-size: 13px;
            color: #64748b;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .unread-dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            background: #ff6b6b;
            border-radius: 50%;
            margin-left: 8px;
        }
        
        .chat-area {
            flex: 1;
            background: white;
            border-radius: 12px;
            display: flex;
            flex-direction: column;
            border: 1px solid #f0f0f0;
        }
        
        .chat-header {
            padding: 20px;
            border-bottom: 1px solid #f0f0f0;
            display: flex;
            gap: 15px;
            align-items: center;
        }
        
        .chat-product-img {
            width: 60px;
            height: 60px;
            border-radius: 8px;
            object-fit: cover;
        }
        
        .chat-product-info h3 {
            font-size: 16px;
            margin-bottom: 4px;
        }
        
        .chat-product-info p {
            font-size: 13px;
            color: #64748b;
        }
        
        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .message {
            max-width: 70%;
            padding: 12px 16px;
            border-radius: 12px;
            position: relative;
        }
        
        .message.received {
            align-self: flex-start;
            background: #f1f5f9;
            color: #1e293b;
        }
        
        .message.sent {
            align-self: flex-end;
            background: #ff6b6b;
            color: white;
        }
        
        .message-time {
            font-size: 10px;
            margin-top: 5px;
            opacity: 0.7;
        }
        
        .chat-input {
            padding: 20px;
            border-top: 1px solid #f0f0f0;
            display: flex;
            gap: 10px;
        }
        
        .chat-input input {
            flex: 1;
            padding: 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
        }
        
        .chat-input input:focus {
            outline: none;
            border-color: #ff6b6b;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 12px;
        }
        
        .empty-state-icon {
            font-size: 64px;
            color: #cbd5e1;
            margin-bottom: 20px;
        }
        
        .empty-state h3 {
            font-size: 18px;
            color: #1e293b;
            margin-bottom: 8px;
        }
        
        .empty-state p {
            color: #64748b;
        }
        
        /* Floating Action Button */
        .fab {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: #ff6b6b;
            color: white;
            border: none;
            font-size: 24px;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(255,107,107,0.3);
            transition: all 0.3s;
            z-index: 99;
        }
        
        .fab:hover {
            transform: scale(1.1);
            background: #ff5252;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <span class="logo-primary">Prop</span><span class="logo-secondary">Mart</span>
                <span style="font-size: 12px; background: #ff6b6b; padding: 2px 8px; border-radius: 4px; margin-left: 8px;">Seller</span>
            </div>
            <div class="seller-badge">
                <div class="seller-name"><?php echo htmlspecialchars($user['business_name'] ?? $user['name']); ?></div>
                <div class="seller-store"><?php echo htmlspecialchars($user['email']); ?></div>
                <span class="verification-badge">
                    <i class="fas fa-check-circle"></i> Verified Seller
                </span>
            </div>
        </div>
        
        <div class="sidebar-nav">
            <a href="?page=dashboard" class="nav-item <?php echo $page === 'dashboard' ? 'active' : ''; ?>">
                <span class="nav-icon"><i class="fas fa-home"></i></span>
                <span class="nav-text">Dashboard</span>
            </a>
            <a href="?page=inventory" class="nav-item <?php echo $page === 'inventory' ? 'active' : ''; ?>">
                <span class="nav-icon"><i class="fas fa-box"></i></span>
                <span class="nav-text">Inventory</span>
                <?php if ($low_stock_count > 0): ?>
                    <span class="nav-badge"><?php echo $low_stock_count; ?></span>
                <?php endif; ?>
            </a>
            <a href="?page=orders" class="nav-item <?php echo $page === 'orders' ? 'active' : ''; ?>">
                <span class="nav-icon"><i class="fas fa-shopping-cart"></i></span>
                <span class="nav-text">Orders</span>
                <?php 
                $pending_orders = 0;
                if ($orders_result) {
                    mysqli_data_seek($orders_result, 0);
                    while ($order = mysqli_fetch_assoc($orders_result)) {
                        if ($order['status'] === 'pending') $pending_orders++;
                    }
                }
                if ($pending_orders > 0): ?>
                    <span class="nav-badge"><?php echo $pending_orders; ?></span>
                <?php endif; ?>
            </a>
            <a href="?page=messages" class="nav-item <?php echo $page === 'messages' ? 'active' : ''; ?>">
                <span class="nav-icon"><i class="fas fa-comment"></i></span>
                <span class="nav-text">Messages</span>
                <?php 
                $unread_messages = 0;
                if ($messages_result) {
                    mysqli_data_seek($messages_result, 0);
                    while ($conv = mysqli_fetch_assoc($messages_result)) {
                        $unread_messages += $conv['unread_count'];
                    }
                }
                if ($unread_messages > 0): ?>
                    <span class="nav-badge"><?php echo $unread_messages; ?></span>
                <?php endif; ?>
            </a>
            <a href="?page=reports" class="nav-item <?php echo $page === 'reports' ? 'active' : ''; ?>">
                <span class="nav-icon"><i class="fas fa-chart-bar"></i></span>
                <span class="nav-text">Reports</span>
            </a>
            <a href="?page=payment" class="nav-item <?php echo $page === 'payment' ? 'active' : ''; ?>">
                <span class="nav-icon"><i class="fas fa-wallet"></i></span>
                <span class="nav-text">Payment</span>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="top-bar">
            <h1 class="page-title">
                <?php 
                if ($page === 'dashboard') echo 'Dashboard';
                elseif ($page === 'inventory') echo 'Inventory Management';
                elseif ($page === 'orders') echo 'Order Management';
                elseif ($page === 'messages') echo 'Messages';
                elseif ($page === 'reports') echo 'Reports & Analytics';
                elseif ($page === 'payment') echo 'Payment & Payouts';
                ?>
            </h1>
            <div class="user-menu">
                <div class="notification-icon">
                    <i class="fas fa-bell" style="font-size: 20px; color: #475569;"></i>
                    <?php if ($low_stock_count > 0 || $pending_orders > 0 || $unread_messages > 0): ?>
                        <span class="notification-badge"><?php echo $low_stock_count + $pending_orders + $unread_messages; ?></span>
                    <?php endif; ?>
                </div>
                <div class="user-avatar">
                    <?php echo strtoupper(substr($user['name'], 0, 1)); ?>
                </div>
                <a href="../logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>

        <div class="container">
            <?php if (isset($_SESSION['message'])): ?>
                <div style="background: #d1fae5; color: #059669; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-check-circle"></i>
                    <?php 
                    echo $_SESSION['message']; 
                    unset($_SESSION['message']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if ($page === 'dashboard'): ?>
                <!-- Dashboard Stats -->
                <div class="stats-grid">
                    <div class="stat-card" onclick="window.location.href='?page=inventory'">
                        <div class="stat-header">
                            <div class="stat-icon blue">
                                <i class="fas fa-box"></i>
                            </div>
                            <span class="stat-trend trend-up"><i class="fas fa-arrow-up"></i> +12%</span>
                        </div>
                        <div class="stat-value"><?php echo $products_count; ?></div>
                        <div class="stat-label">Total Products</div>
                        <?php if ($low_stock_count > 0): ?>
                            <div style="margin-top: 8px; font-size: 12px; color: #f97316;">
                                <i class="fas fa-exclamation-triangle"></i> <?php echo $low_stock_count; ?> low stock
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="stat-card" onclick="window.location.href='?page=orders'">
                        <div class="stat-header">
                            <div class="stat-icon green">
                                <i class="fas fa-shopping-cart"></i>
                            </div>
                            <span class="stat-trend trend-up"><i class="fas fa-arrow-up"></i> +8%</span>
                        </div>
                        <div class="stat-value"><?php echo $orders_count; ?></div>
                        <div class="stat-label">Total Orders</div>
                        <?php if ($pending_orders > 0): ?>
                            <div style="margin-top: 8px; font-size: 12px; color: #f97316;">
                                <i class="fas fa-clock"></i> <?php echo $pending_orders; ?> pending
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="stat-card" onclick="window.location.href='?page=payment'">
                        <div class="stat-header">
                            <div class="stat-icon orange">
                                <i class="fas fa-dollar-sign"></i>
                            </div>
                            <span class="stat-trend trend-up"><i class="fas fa-arrow-up"></i> +23%</span>
                        </div>
                        <div class="stat-value">₱<?php echo number_format($earnings['total'] ?? 0); ?></div>
                        <div class="stat-label">Total Earnings</div>
                    </div>
                    
                    <div class="stat-card" onclick="window.location.href='?page=messages'">
                        <div class="stat-header">
                            <div class="stat-icon red">
                                <i class="fas fa-comment"></i>
                            </div>
                            <span class="stat-trend">Active</span>
                        </div>
                        <div class="stat-value"><?php echo mysqli_num_rows($messages_result); ?></div>
                        <div class="stat-label">Conversations</div>
                        <?php if ($unread_messages > 0): ?>
                            <div style="margin-top: 8px; font-size: 12px; color: #ff6b6b;">
                                <i class="fas fa-envelope"></i> <?php echo $unread_messages; ?> unread
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div style="display: flex; gap: 15px; margin-bottom: 30px;">
                    <button class="btn btn-primary" onclick="openAddProductModal()">
                        <i class="fas fa-plus"></i> Add New Product
                    </button>
                    <button class="btn btn-outline" onclick="window.location.href='?page=reports'">
                        <i class="fas fa-chart-line"></i> View Reports
                    </button>
                </div>

                <!-- Recent Products -->
                <div style="background: white; border-radius: 12px; padding: 20px; margin-bottom: 30px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                        <h3 style="font-size: 18px;">Recent Products</h3>
                        <a href="?page=inventory" style="color: #ff6b6b; text-decoration: none;">View All →</a>
                    </div>
                    
                    <div class="product-grid">
                        <?php 
                        if ($products_result && mysqli_num_rows($products_result) > 0) {
                            $count = 0;
                            mysqli_data_seek($products_result, 0);
                            while ($product = mysqli_fetch_assoc($products_result)) {
                                if ($count >= 4) break;
                                $count++;
                                $images = json_decode($product['images'], true);
                                
                                // Stock percentage for bar
                                $stock_percentage = min(100, ($product['stock'] / 10) * 100);
                                $stock_class = '';
                                if ($product['stock'] == 0) {
                                    $stock_class = 'critical';
                                } elseif ($product['stock'] <= $product['low_stock_threshold']) {
                                    $stock_class = 'low';
                                }
                        ?>
                                <div class="product-card">
                                    <div class="product-image-container">
                                        <img class="product-image" src="<?php echo isset($images[0]) ? $images[0] : ''; ?>" alt="">
                                        <?php if ($product['stock'] == 0): ?>
                                            <span class="product-badge">Out of Stock</span>
                                        <?php elseif ($product['stock'] <= $product['low_stock_threshold']): ?>
                                            <span class="product-badge" style="background: #f97316;">Low Stock</span>
                                        <?php endif; ?>
                                        <span class="product-type-badge">
                                            <?php 
                                            if ($product['type'] == 'buy') echo 'For Sale';
                                            elseif ($product['type'] == 'rent') echo 'For Rent';
                                            else echo 'Sale & Rent';
                                            ?>
                                        </span>
                                    </div>
                                    <div class="product-info">
                                        <div class="product-title"><?php echo htmlspecialchars($product['title']); ?></div>
                                        <div class="product-prices">
                                            <?php if ($product['buy_price']): ?>
                                                <span class="buy-price">₱<?php echo number_format($product['buy_price']); ?></span>
                                            <?php endif; ?>
                                            <?php if ($product['rent_price']): ?>
                                                <span class="rent-price">₱<?php echo number_format($product['rent_price']); ?>/day</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="product-stock">
                                            <div class="stock-bar">
                                                <div class="stock-fill <?php echo $stock_class; ?>" style="width: <?php echo $stock_percentage; ?>%;"></div>
                                            </div>
                                            <span class="stock-text"><?php echo $product['stock']; ?> left</span>
                                        </div>
                                        <div class="product-actions">
                                            <button class="btn btn-sm btn-outline" onclick="editProduct(<?php echo $product['id']; ?>, 
                                                '<?php echo addslashes($product['title']); ?>', 
                                                '<?php echo addslashes($product['description']); ?>', 
                                                '<?php echo $product['category']; ?>', 
                                                '<?php echo $product['type']; ?>', 
                                                <?php echo $product['buy_price'] ?: 'null'; ?>, 
                                                <?php echo $product['rent_price'] ?: 'null'; ?>, 
                                                '<?php echo addslashes($product['location']); ?>', 
                                                <?php echo $product['stock']; ?>,
                                                <?php echo $product['low_stock_threshold']; ?>,
                                                '<?php echo isset($images[0]) ? addslashes($images[0]) : ''; ?>')">
                                                <i class="fas fa-edit"></i> Edit
                                            </button>
                                            <button class="btn btn-sm btn-outline" onclick="openReplenishModal(<?php echo $product['id']; ?>, '<?php echo addslashes($product['title']); ?>')">
                                                <i class="fas fa-plus-circle"></i> Replenish
                                            </button>
                                        </div>
                                    </div>
                                </div>
                        <?php 
                            }
                        } else { 
                            echo '<div class="empty-state" style="grid-column: 1/-1;">
                                <div class="empty-state-icon">📦</div>
                                <h3>No products yet</h3>
                                <p>Click "Add New Product" to start selling</p>
                            </div>';
                        } 
                        ?>
                    </div>
                </div>

                <!-- Active Rentals -->
                <?php if (mysqli_num_rows($active_rentals_result) > 0): ?>
                <div style="background: white; border-radius: 12px; padding: 20px;">
                    <h3 style="font-size: 18px; margin-bottom: 20px;">Active Rentals</h3>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Buyer</th>
                                    <th>Rental Period</th>
                                    <th>Days Left</th>
                                    <th>Amount</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                mysqli_data_seek($active_rentals_result, 0);
                                while ($rental = mysqli_fetch_assoc($active_rentals_result)): 
                                    $images = json_decode($rental['images'], true);
                                    $days_left = ceil((strtotime($rental['end_date']) - time()) / (60 * 60 * 24));
                                ?>
                                <tr>
                                    <td>
                                        <div class="table-product">
                                            <img src="<?php echo isset($images[0]) ? $images[0] : ''; ?>" class="table-product-img">
                                            <span><?php echo htmlspecialchars($rental['title']); ?></span>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($rental['buyer_name']); ?></td>
                                    <td><?php echo $rental['start_date']; ?> to <?php echo $rental['end_date']; ?></td>
                                    <td>
                                        <?php if ($days_left <= 2): ?>
                                            <span class="badge badge-danger"><?php echo $days_left; ?> days</span>
                                        <?php else: ?>
                                            <span class="badge badge-success"><?php echo $days_left; ?> days</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>₱<?php echo number_format($rental['amount']); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-success" onclick="openConfirmModal('return', <?php echo $rental['id']; ?>)">
                                            <i class="fas fa-undo"></i> Mark Returned
                                        </button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>

            <?php elseif ($page === 'inventory'): ?>
                <!-- Inventory Tabs -->
                <div class="tabs">
                    <div class="tab <?php echo $tab === 'all' ? 'active' : ''; ?>" onclick="window.location.href='?page=inventory&tab=all'">
                        All Products <span class="tab-badge"><?php echo $products_count; ?></span>
                    </div>
                    <div class="tab <?php echo $tab === 'low-stock' ? 'active' : ''; ?>" onclick="window.location.href='?page=inventory&tab=low-stock'">
                        Low Stock <span class="tab-badge"><?php echo $low_stock_count; ?></span>
                    </div>
                    <div class="tab <?php echo $tab === 'out-of-stock' ? 'active' : ''; ?>" onclick="window.location.href='?page=inventory&tab=out-of-stock'">
                        Out of Stock <span class="tab-badge"><?php echo $out_of_stock_count; ?></span>
                    </div>
                    <div class="tab <?php echo $tab === 'replenishment' ? 'active' : ''; ?>" onclick="window.location.href='?page=inventory&tab=replenishment'">
                        Replenishment History
                    </div>
                    <div class="tab <?php echo $tab === 'sales' ? 'active' : ''; ?>" onclick="window.location.href='?page=inventory&tab=sales'">
                        Sales History
                    </div>
                </div>

                <?php if ($tab === 'replenishment'): ?>
                    <!-- Replenishment History -->
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Date & Time</th>
                                    <th>Product</th>
                                    <th>Previous Stock</th>
                                    <th>Added</th>
                                    <th>New Stock</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                if ($inventory_log_result && mysqli_num_rows($inventory_log_result) > 0) {
                                    while ($log = mysqli_fetch_assoc($inventory_log_result)) {
                                        echo '<tr>';
                                        echo '<td>' . date('M d, Y h:i A', strtotime($log['created_at'])) . '</td>';
                                        echo '<td>' . htmlspecialchars($log['title']) . '</td>';
                                        echo '<td>' . $log['previous_stock'] . '</td>';
                                        echo '<td><span class="badge badge-success">+' . ($log['new_stock'] - $log['previous_stock']) . '</span></td>';
                                        echo '<td>' . $log['new_stock'] . '</td>';
                                        echo '<td>' . htmlspecialchars($log['notes']) . '</td>';
                                        echo '</tr>';
                                    }
                                } else {
                                    echo '<tr><td colspan="6" class="empty-state">No replenishment history yet</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>

                <?php elseif ($tab === 'sales'): ?>
                    <!-- Sales History -->
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Order #</th>
                                    <th>Product</th>
                                    <th>Buyer</th>
                                    <th>Quantity</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $sales_history_query = "
                                    SELECT o.*, p.title, p.images, u.name as buyer_name
                                    FROM orders o
                                    JOIN products p ON o.product_id = p.id
                                    JOIN users u ON o.buyer_id = u.id
                                    WHERE o.seller_id = $user_id AND o.type = 'buy' AND o.status = 'completed'
                                    ORDER BY o.created_at DESC
                                ";
                                $sales_history = mysqli_query($conn, $sales_history_query);
                                
                                if ($sales_history && mysqli_num_rows($sales_history) > 0) {
                                    while ($sale = mysqli_fetch_assoc($sales_history)) {
                                        $images = json_decode($sale['images'], true);
                                        echo '<tr>';
                                        echo '<td>#' . $sale['order_number'] . '</td>';
                                        echo '<td>
                                            <div class="table-product">
                                                <img src="' . (isset($images[0]) ? $images[0] : '') . '" class="table-product-img">
                                                <span>' . htmlspecialchars($sale['title']) . '</span>
                                            </div>
                                        </td>';
                                        echo '<td>' . htmlspecialchars($sale['buyer_name']) . '</td>';
                                        echo '<td>' . $sale['quantity'] . '</td>';
                                        echo '<td>₱' . number_format($sale['amount']) . '</td>';
                                        echo '<td>' . date('M d, Y', strtotime($sale['created_at'])) . '</td>';
                                        echo '<td><span class="badge badge-success">Completed</span></td>';
                                        echo '</tr>';
                                    }
                                } else {
                                    echo '<tr><td colspan="7" class="empty-state">No sales yet</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>

                <?php else: ?>
                    <!-- Product Grid View -->
                    <div style="display: flex; justify-content: flex-end; margin-bottom: 20px;">
                        <button class="btn btn-primary" onclick="openAddProductModal()">
                            <i class="fas fa-plus"></i> Add New Product
                        </button>
                    </div>

                    <div class="product-grid">
                        <?php 
                        if ($products_result && mysqli_num_rows($products_result) > 0) {
                            mysqli_data_seek($products_result, 0);
                            while ($product = mysqli_fetch_assoc($products_result)) {
                                // Filter by tab
                                if ($tab === 'low-stock' && ($product['stock'] > $product['low_stock_threshold'] || $product['stock'] == 0)) continue;
                                if ($tab === 'out-of-stock' && $product['stock'] > 0) continue;
                                
                                $images = json_decode($product['images'], true);
                                
                                // Stock percentage for bar
                                $stock_percentage = min(100, ($product['stock'] / 10) * 100);
                                $stock_class = '';
                                if ($product['stock'] == 0) {
                                    $stock_class = 'critical';
                                } elseif ($product['stock'] <= $product['low_stock_threshold']) {
                                    $stock_class = 'low';
                                }
                        ?>
                                <div class="product-card">
                                    <div class="product-image-container">
                                        <img class="product-image" src="<?php echo isset($images[0]) ? $images[0] : ''; ?>" alt="">
                                        <?php if ($product['stock'] == 0): ?>
                                            <span class="product-badge">Out of Stock</span>
                                        <?php elseif ($product['stock'] <= $product['low_stock_threshold']): ?>
                                            <span class="product-badge" style="background: #f97316;">Low Stock</span>
                                        <?php endif; ?>
                                        <span class="product-type-badge">
                                            <?php 
                                            if ($product['type'] == 'buy') echo 'For Sale';
                                            elseif ($product['type'] == 'rent') echo 'For Rent';
                                            else echo 'Sale & Rent';
                                            ?>
                                        </span>
                                    </div>
                                    <div class="product-info">
                                        <div class="product-title"><?php echo htmlspecialchars($product['title']); ?></div>
                                        <div class="product-prices">
                                            <?php if ($product['buy_price']): ?>
                                                <span class="buy-price">₱<?php echo number_format($product['buy_price']); ?></span>
                                            <?php endif; ?>
                                            <?php if ($product['rent_price']): ?>
                                                <span class="rent-price">₱<?php echo number_format($product['rent_price']); ?>/day</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="product-stock">
                                            <div class="stock-bar">
                                                <div class="stock-fill <?php echo $stock_class; ?>" style="width: <?php echo $stock_percentage; ?>%;"></div>
                                            </div>
                                            <span class="stock-text"><?php echo $product['stock']; ?> left</span>
                                        </div>
                                        <div class="product-actions">
                                            <button class="btn btn-sm btn-primary" onclick="editProduct(<?php echo $product['id']; ?>, 
                                                '<?php echo addslashes($product['title']); ?>', 
                                                '<?php echo addslashes($product['description']); ?>', 
                                                '<?php echo $product['category']; ?>', 
                                                '<?php echo $product['type']; ?>', 
                                                <?php echo $product['buy_price'] ?: 'null'; ?>, 
                                                <?php echo $product['rent_price'] ?: 'null'; ?>, 
                                                '<?php echo addslashes($product['location']); ?>', 
                                                <?php echo $product['stock']; ?>,
                                                <?php echo $product['low_stock_threshold']; ?>,
                                                '<?php echo isset($images[0]) ? addslashes($images[0]) : ''; ?>')">
                                                <i class="fas fa-edit"></i> Edit
                                            </button>
                                            <button class="btn btn-sm btn-success" onclick="openReplenishModal(<?php echo $product['id']; ?>, '<?php echo addslashes($product['title']); ?>')">
                                                <i class="fas fa-plus-circle"></i> Replenish
                                            </button>
                                            <button class="btn btn-sm btn-outline" onclick="openConfirmModal('delete', <?php echo $product['id']; ?>)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                        <?php 
                            }
                        } else { 
                            echo '<div class="empty-state" style="grid-column: 1/-1;">
                                <div class="empty-state-icon">📦</div>
                                <h3>No products yet</h3>
                                <p>Click "Add New Product" to start selling</p>
                            </div>';
                        } 
                        ?>
                    </div>
                <?php endif; ?>

            <?php elseif ($page === 'reports'): ?>
                <!-- Reports & Analytics -->
                <div class="reports-grid">
                    <div class="report-card">
                        <div class="report-header">
                            <span class="report-title">Total Sales</span>
                            <i class="fas fa-dollar-sign" style="color: #ff6b6b; font-size: 24px;"></i>
                        </div>
                        <div class="report-value">₱<?php echo number_format($earnings['total'] ?? 0); ?></div>
                        <div class="report-sub">Lifetime earnings from all orders</div>
                    </div>
                    
                    <div class="report-card">
                        <div class="report-header">
                            <span class="report-title">Orders Completed</span>
                            <i class="fas fa-shopping-bag" style="color: #4ecdc4; font-size: 24px;"></i>
                        </div>
                        <?php 
                        $completed_orders_query = "SELECT COUNT(*) as total FROM orders WHERE seller_id = $user_id AND status = 'completed'";
                        $completed_orders = mysqli_fetch_assoc(mysqli_query($conn, $completed_orders_query));
                        ?>
                        <div class="report-value"><?php echo $completed_orders['total'] ?? 0; ?></div>
                        <div class="report-sub">Total completed transactions</div>
                    </div>
                    
                    <div class="report-card">
                        <div class="report-header">
                            <span class="report-title">Buy vs Rent</span>
                            <i class="fas fa-chart-pie" style="color: #f97316; font-size: 24px;"></i>
                        </div>
                        <?php 
                        $buy_count_query = "SELECT COUNT(*) as total FROM orders WHERE seller_id = $user_id AND type = 'buy' AND status = 'completed'";
                        $rent_count_query = "SELECT COUNT(*) as total FROM orders WHERE seller_id = $user_id AND type = 'rent' AND status = 'completed'";
                        $buy_count = mysqli_fetch_assoc(mysqli_query($conn, $buy_count_query));
                        $rent_count = mysqli_fetch_assoc(mysqli_query($conn, $rent_count_query));
                        ?>
                        <div style="display: flex; gap: 20px; margin-top: 15px;">
                            <div>
                                <span style="color: #ff6b6b; font-weight: 700;"><?php echo $buy_count['total'] ?? 0; ?></span>
                                <span style="color: #64748b; font-size: 13px;"> Purchases</span>
                            </div>
                            <div>
                                <span style="color: #4ecdc4; font-weight: 700;"><?php echo $rent_count['total'] ?? 0; ?></span>
                                <span style="color: #64748b; font-size: 13px;"> Rentals</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="report-card">
                        <div class="report-header">
                            <span class="report-title">Average Order Value</span>
                            <i class="fas fa-calculator" style="color: #8b5cf6; font-size: 24px;"></i>
                        </div>
                        <?php 
                        $avg_query = "SELECT AVG(amount) as avg FROM orders WHERE seller_id = $user_id AND status = 'completed'";
                        $avg_result = mysqli_fetch_assoc(mysqli_query($conn, $avg_query));
                        ?>
                        <div class="report-value">₱<?php echo number_format($avg_result['avg'] ?? 0); ?></div>
                        <div class="report-sub">Per completed order</div>
                    </div>
                </div>

                <!-- Sales Chart (simplified) -->
                <div style="background: white; border-radius: 12px; padding: 20px; margin-bottom: 30px;">
                    <h3 style="margin-bottom: 20px;">Recent Sales (Last 30 Days)</h3>
                    <div style="display: flex; align-items: flex-end; gap: 10px; height: 200px;">
                        <?php 
                        if ($sales_result && mysqli_num_rows($sales_result) > 0) {
                            $max_sales = 0;
                            $sales_data = [];
                            while ($day = mysqli_fetch_assoc($sales_result)) {
                                $sales_data[] = $day;
                                if ($day['total_sales'] > $max_sales) $max_sales = $day['total_sales'];
                            }
                            $sales_data = array_reverse($sales_data);
                            
                            foreach ($sales_data as $day) {
                                $height = $max_sales > 0 ? ($day['total_sales'] / $max_sales) * 180 : 0;
                                echo '<div style="flex: 1; display: flex; flex-direction: column; align-items: center;">';
                                echo '<div style="height: ' . $height . 'px; width: 30px; background: #ff6b6b; border-radius: 4px 4px 0 0;"></div>';
                                echo '<div style="margin-top: 8px; font-size: 11px; color: #64748b;">' . date('M d', strtotime($day['sale_date'])) . '</div>';
                                echo '<div style="font-size: 11px; font-weight: 600;">₱' . number_format($day['total_sales']) . '</div>';
                                echo '</div>';
                            }
                        } else {
                            echo '<div style="width: 100%; text-align: center; color: #94a3b8;">No sales data available</div>';
                        }
                        ?>
                    </div>
                </div>

                <!-- Top Products -->
                <div style="background: white; border-radius: 12px; padding: 20px;">
                    <h3 style="margin-bottom: 20px;">Top Selling Products</h3>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Total Sold</th>
                                    <th>Revenue</th>
                                    <th>Rentals</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $top_products_query = "
                                    SELECT p.id, p.title, p.images,
                                           SUM(CASE WHEN o.type = 'buy' AND o.status = 'completed' THEN o.quantity ELSE 0 END) as total_sold,
                                           SUM(CASE WHEN o.type = 'buy' AND o.status = 'completed' THEN o.amount ELSE 0 END) as buy_revenue,
                                           COUNT(CASE WHEN o.type = 'rent' AND o.status = 'completed' THEN 1 END) as rental_count
                                    FROM products p
                                    LEFT JOIN orders o ON p.id = o.product_id
                                    WHERE p.seller_id = $user_id
                                    GROUP BY p.id
                                    ORDER BY total_sold DESC
                                    LIMIT 5
                                ";
                                $top_products = mysqli_query($conn, $top_products_query);
                                
                                if ($top_products && mysqli_num_rows($top_products) > 0) {
                                    while ($top = mysqli_fetch_assoc($top_products)) {
                                        $images = json_decode($top['images'], true);
                                        echo '<tr>';
                                        echo '<td>
                                            <div class="table-product">
                                                <img src="' . (isset($images[0]) ? $images[0] : '') . '" class="table-product-img">
                                                <span>' . htmlspecialchars($top['title']) . '</span>
                                            </div>
                                        </td>';
                                        echo '<td><span class="badge badge-success">' . ($top['total_sold'] ?? 0) . ' sold</span></td>';
                                        echo '<td>₱' . number_format($top['buy_revenue'] ?? 0) . '</td>';
                                        echo '<td><span class="badge badge-info">' . ($top['rental_count'] ?? 0) . ' rentals</span></td>';
                                        echo '</tr>';
                                    }
                                } else {
                                    echo '<tr><td colspan="4" class="empty-state">No sales data yet</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            <?php elseif ($page === 'orders'): ?>
                <!-- Orders Page (similar to before but with Shopee style) -->
                <div style="display: flex; gap: 20px; margin-bottom: 30px;">
                    <div class="stat-card" style="flex: 1;">
                        <div class="stat-value"><?php echo $orders_count; ?></div>
                        <div class="stat-label">Total Orders</div>
                    </div>
                    <div class="stat-card" style="flex: 1;">
                        <div class="stat-value"><?php echo $pending_orders; ?></div>
                        <div class="stat-label">Pending</div>
                    </div>
                    <div class="stat-card" style="flex: 1;">
                        <div class="stat-value"><?php echo mysqli_num_rows($active_rentals_result); ?></div>
                        <div class="stat-label">Active Rentals</div>
                    </div>
                </div>

                <div class="tabs">
                    <div class="tab active">All Orders</div>
                    <div class="tab">Pending</div>
                    <div class="tab">Active Rentals</div>
                    <div class="tab">Completed</div>
                </div>

                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Product</th>
                                <th>Buyer</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if ($orders_result && mysqli_num_rows($orders_result) > 0) {
                                mysqli_data_seek($orders_result, 0);
                                while ($order = mysqli_fetch_assoc($orders_result)) { 
                                    $images = json_decode($order['images'], true);
                            ?>
                                <tr>
                                    <td>#<?php echo $order['order_number']; ?></td>
                                    <td>
                                        <div class="table-product">
                                            <img src="<?php echo isset($images[0]) ? $images[0] : ''; ?>" class="table-product-img">
                                            <span><?php echo htmlspecialchars($order['title']); ?></span>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($order['buyer_name']); ?></td>
                                    <td>
                                        <?php if ($order['type'] == 'buy'): ?>
                                            <span class="badge badge-success">Purchase</span>
                                        <?php else: ?>
                                            <span class="badge badge-info">Rental</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>₱<?php echo number_format($order['amount']); ?></td>
                                    <td>
                                        <?php
                                        $status_class = '';
                                        if ($order['status'] == 'pending') $status_class = 'badge-warning';
                                        elseif ($order['status'] == 'confirmed') $status_class = 'badge-info';
                                        elseif ($order['status'] == 'completed') $status_class = 'badge-success';
                                        elseif ($order['status'] == 'cancelled') $status_class = 'badge-danger';
                                        ?>
                                        <span class="badge <?php echo $status_class; ?>"><?php echo ucfirst($order['status']); ?></span>
                                        <?php if ($order['type'] == 'rent' && $order['returned']): ?>
                                            <br><small class="badge badge-success" style="margin-top: 4px;">Returned</small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                                    <td>
                                        <?php if ($order['status'] === 'pending'): ?>
                                            <button class="btn btn-sm btn-success" onclick="openConfirmModal('accept', <?php echo $order['id']; ?>)">
                                                Accept
                                            </button>
                                            <button class="btn btn-sm btn-danger" onclick="openConfirmModal('reject', <?php echo $order['id']; ?>)">
                                                Reject
                                            </button>
                                        <?php elseif ($order['status'] === 'confirmed' && $order['type'] === 'rent' && !$order['returned']): ?>
                                            <button class="btn btn-sm btn-success" onclick="openConfirmModal('return', <?php echo $order['id']; ?>)">
                                                <i class="fas fa-undo"></i> Return
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php 
                                }
                            } else { 
                                echo '<tr><td colspan="8" class="empty-state">No orders yet</td></tr>';
                            } 
                            ?>
                        </tbody>
                    </table>
                </div>

            <?php elseif ($page === 'messages'): ?>
                <!-- Messages/Chat -->
                <div class="inbox-container">
                    <div class="conversation-list">
                        <?php 
                        if ($messages_result && mysqli_num_rows($messages_result) > 0) {
                            mysqli_data_seek($messages_result, 0);
                            while ($conv = mysqli_fetch_assoc($messages_result)): 
                                $active_class = ($selected_buyer == $conv['buyer_id'] && $selected_product == $conv['product_id']) ? 'active' : '';
                                $unread_class = ($conv['unread_count'] > 0) ? 'unread' : '';
                                $avatar_letter = strtoupper(substr($conv['buyer_name'], 0, 1));
                        ?>
                                <a href="?page=messages&buyer_id=<?php echo $conv['buyer_id']; ?>&product_id=<?php echo $conv['product_id']; ?>" 
                                   style="text-decoration: none; color: inherit;">
                                    <div class="conversation-item <?php echo $active_class . ' ' . $unread_class; ?>">
                                        <div class="conversation-avatar">
                                            <?php echo $avatar_letter; ?>
                                        </div>
                                        <div class="conversation-info">
                                            <div class="conversation-header">
                                                <span class="conversation-name"><?php echo htmlspecialchars($conv['buyer_name']); ?></span>
                                                <span class="conversation-time">
                                                    <?php echo $conv['last_time'] ? date('M d', strtotime($conv['last_time'])) : ''; ?>
                                                    <?php if ($conv['unread_count'] > 0): ?>
                                                        <span class="unread-dot"></span>
                                                    <?php endif; ?>
                                                </span>
                                            </div>
                                            <div class="conversation-product">
                                                📦 <?php echo htmlspecialchars($conv['product_title']); ?>
                                                <?php if ($conv['stock'] <= $conv['low_stock_threshold']): ?>
                                                    <span style="color: #f97316;">(Low Stock)</span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="conversation-preview">
                                                <?php echo $conv['last_message'] ? htmlspecialchars(substr($conv['last_message'], 0, 50)) . '...' : 'No messages yet'; ?>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                        <?php 
                            endwhile; 
                        } else {
                            echo '<div style="padding: 30px; text-align: center; color: #94a3b8;">
                                    <i class="fas fa-comments" style="font-size: 48px; margin-bottom: 15px;"></i>
                                    <p>No messages yet. When customers message you, they will appear here.</p>
                                  </div>';
                        }
                        ?>
                    </div>
                    
                    <div class="chat-area">
                        <?php if (!empty($conversation_messages)): ?>
                            <div class="chat-header">
                                <img src="<?php echo $conversation_product_image; ?>" class="chat-product-img">
                                <div class="chat-product-info">
                                    <h3><?php echo htmlspecialchars($conversation_product_title); ?></h3>
                                    <p>Conversation with <?php echo htmlspecialchars($conversation_buyer_name); ?></p>
                                </div>
                            </div>
                            
                            <div class="chat-messages" id="chatMessages">
                                <?php foreach ($conversation_messages as $msg): 
                                    $is_me = ($msg['sender_id'] == $user_id);
                                ?>
                                    <div class="message <?php echo $is_me ? 'sent' : 'received'; ?>">
                                        <?php echo nl2br(htmlspecialchars($msg['message'])); ?>
                                        <div class="message-time">
                                            <?php echo date('M d, h:i A', strtotime($msg['created_at'])); ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            
                            <div class="chat-input">
                                <input type="text" id="replyMessage" placeholder="Type your message...">
                                <button class="btn btn-primary" onclick="sendReply(<?php echo $selected_buyer; ?>, <?php echo $selected_product; ?>)">
                                    Send
                                </button>
                            </div>
                            
                        <?php else: ?>
                            <div class="empty-state" style="height: 100%; display: flex; flex-direction: column; justify-content: center;">
                                <div class="empty-state-icon">💬</div>
                                <h3>Select a conversation</h3>
                                <p>Choose a conversation from the sidebar to view messages</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            <?php elseif ($page === 'payment'): ?>
                <!-- Payment/Payout Page (similar to before) -->
                <div class="reports-grid">
                    <div class="report-card">
                        <div class="report-header">
                            <span class="report-title">Available Balance</span>
                            <i class="fas fa-wallet" style="color: #10b981; font-size: 24px;"></i>
                        </div>
                        <div class="report-value">₱<?php echo number_format(($earnings['total'] ?? 0) - ($pending_payouts['total'] ?? 0)); ?></div>
                        <button class="btn btn-success" style="margin-top: 15px;" onclick="openPayoutModal(<?php echo ($earnings['total'] ?? 0) - ($pending_payouts['total'] ?? 0); ?>)">
                            <i class="fas fa-money-bill-wave"></i> Request Payout
                        </button>
                    </div>
                    
                    <div class="report-card">
                        <div class="report-header">
                            <span class="report-title">Total Earnings</span>
                            <i class="fas fa-chart-line" style="color: #ff6b6b; font-size: 24px;"></i>
                        </div>
                        <div class="report-value">₱<?php echo number_format($earnings['total'] ?? 0); ?></div>
                        <div class="report-sub">Lifetime earnings</div>
                    </div>
                    
                    <div class="report-card">
                        <div class="report-header">
                            <span class="report-title">Pending Payouts</span>
                            <i class="fas fa-clock" style="color: #f97316; font-size: 24px;"></i>
                        </div>
                        <div class="report-value">₱<?php echo number_format($pending_payouts['total'] ?? 0); ?></div>
                        <div class="report-sub">Awaiting processing</div>
                    </div>
                    
                    <div class="report-card">
                        <div class="report-header">
                            <span class="report-title">This Month</span>
                            <i class="fas fa-calendar" style="color: #8b5cf6; font-size: 24px;"></i>
                        </div>
                        <div class="report-value">₱<?php echo number_format(($earnings['total'] ?? 0) * 0.3); ?></div>
                        <div class="report-sub">Estimated</div>
                    </div>
                </div>

                <div style="background: white; border-radius: 12px; padding: 20px; margin-top: 30px;">
                    <h3 style="margin-bottom: 20px;">Transaction History</h3>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Description</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                if ($transactions_result && mysqli_num_rows($transactions_result) > 0) {
                                    while ($trans = mysqli_fetch_assoc($transactions_result)) { 
                                ?>
                                        <tr>
                                            <td><?php echo date('M d, Y', strtotime($trans['created_at'])); ?></td>
                                            <td><?php echo htmlspecialchars($trans['description']); ?></td>
                                            <td class="<?php echo $trans['type'] === 'in' ? 'amount-in' : 'amount-out'; ?>" style="font-weight: 600;">
                                                <?php echo $trans['type'] === 'in' ? '+' : '-'; ?>₱<?php echo number_format($trans['amount']); ?>
                                            </td>
                                            <td>
                                                <span class="badge <?php echo $trans['status'] === 'completed' ? 'badge-success' : 'badge-warning'; ?>">
                                                    <?php echo ucfirst($trans['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                <?php 
                                    }
                                } else { 
                                    echo '<tr><td colspan="4" class="empty-state">No transactions yet</td></tr>';
                                } 
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Floating Action Button -->
    <?php if ($page === 'inventory'): ?>
        <button class="fab" onclick="openAddProductModal()">
            <i class="fas fa-plus"></i>
        </button>
    <?php endif; ?>

    <!-- Add/Edit Product Modal -->
    <div class="modal-overlay" id="productModal">
        <div class="modal">
            <div class="modal-header">
                <h2 id="modalTitle">Add New Product</h2>
                <button class="modal-close" onclick="closeModal()">&times;</button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" id="formAction" value="add_product">
                    <input type="hidden" name="product_id" id="productId">
                    
                    <div class="form-group">
                        <label>Product Title</label>
                        <input type="text" name="title" id="title" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Category</label>
                        <select name="category" id="category" class="form-control" required>
                            <option value="electronics">Electronics</option>
                            <option value="gaming">Gaming</option>
                            <option value="furniture">Furniture</option>
                            <option value="vehicles">Vehicles</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Type</label>
                        <select name="type" id="type" class="form-control" required onchange="togglePriceFields()">
                            <option value="buy">For Sale Only</option>
                            <option value="rent">For Rent Only</option>
                            <option value="both">Both</option>
                        </select>
                    </div>
                    
                    <div class="form-group" id="buyPriceGroup">
                        <label>Selling Price (₱)</label>
                        <input type="number" name="buy_price" id="buyPrice" class="form-control">
                    </div>
                    
                    <div class="form-group" id="rentPriceGroup" style="display: none;">
                        <label>Rent Price (₱/day)</label>
                        <input type="number" name="rent_price" id="rentPrice" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label>Location</label>
                        <input type="text" name="location" id="location" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Initial Stock</label>
                        <input type="number" name="stock" id="stock" class="form-control" value="1" min="0">
                    </div>
                    
                    <div class="form-group">
                        <label>Low Stock Threshold</label>
                        <input type="number" name="low_stock_threshold" id="lowStockThreshold" class="form-control" value="3" min="1">
                        <small style="color: #64748b;">You'll be alerted when stock reaches this number</small>
                    </div>
                    
                    <div class="form-group">
                        <label>Image URL</label>
                        <input type="url" name="image" id="image" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" id="description" class="form-control" rows="4" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-confirm">Save Product</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Replenish Stock Modal -->
    <div class="modal-overlay" id="replenishModal">
        <div class="modal">
            <div class="modal-header">
                <h2>Replenish Stock</h2>
                <button class="modal-close" onclick="closeReplenishModal()">&times;</button>
            </div>
            <div class="modal-body">
                <p style="margin-bottom: 20px;" id="replenishProductName"></p>
                
                <div class="form-group">
                    <label>Quantity to Add</label>
                    <input type="number" id="replenishQuantity" class="form-control" min="1" value="1">
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn-cancel" onclick="closeReplenishModal()">Cancel</button>
                <button class="btn-confirm" onclick="confirmReplenish()">Replenish Stock</button>
            </div>
        </div>
    </div>

    <!-- Confirmation Modal -->
    <div class="modal-overlay" id="confirmModal">
        <div class="modal confirm-modal">
            <div class="modal-body" style="text-align: center; padding: 40px;">
                <div class="confirm-icon">
                    <i class="fas fa-question-circle"></i>
                </div>
                <div class="confirm-title" id="confirmTitle">Are you sure?</div>
                <div class="confirm-message" id="confirmMessage">This action cannot be undone.</div>
                <div class="confirm-actions">
                    <button class="btn-cancel" onclick="closeConfirmModal()">Cancel</button>
                    <button class="btn-confirm" id="confirmActionBtn">Yes, proceed</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Payout Modal -->
    <div class="modal-overlay" id="payoutModal">
        <div class="modal">
            <div class="modal-header">
                <h2>Request Payout</h2>
                <button class="modal-close" onclick="closePayoutModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div style="background: #d1fae5; padding: 20px; border-radius: 8px; margin-bottom: 20px; text-align: center;">
                    <div style="font-size: 14px; color: #059669; margin-bottom: 5px;">Available Balance</div>
                    <div style="font-size: 32px; font-weight: 800; color: #10b981;" id="availableBalance">₱0</div>
                </div>
                
                <div class="form-group">
                    <label>Amount to Withdraw</label>
                    <input type="number" id="payoutAmount" class="form-control" placeholder="Enter amount" min="100">
                </div>
                
                <div class="form-group">
                    <label>Payout Method</label>
                    <select id="payoutMethod" class="form-control">
                        <option value="Bank Transfer">Bank Transfer (BDO ****1234)</option>
                        <option value="GCash">GCash (0917****5678)</option>
                        <option value="PayPal">PayPal (seller@email.com)</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn-cancel" onclick="closePayoutModal()">Cancel</button>
                <button class="btn-confirm" onclick="requestPayout()">Confirm Withdrawal</button>
            </div>
        </div>
    </div>

    <script>
        let currentAction = null;
        let currentId = null;
        let currentProductId = null;
        let currentProductName = '';

        function togglePriceFields() {
            const type = document.getElementById('type').value;
            const buyGroup = document.getElementById('buyPriceGroup');
            const rentGroup = document.getElementById('rentPriceGroup');
            
            if (type === 'buy') {
                buyGroup.style.display = 'block';
                rentGroup.style.display = 'none';
            } else if (type === 'rent') {
                buyGroup.style.display = 'none';
                rentGroup.style.display = 'block';
            } else {
                buyGroup.style.display = 'block';
                rentGroup.style.display = 'block';
            }
        }

        function openAddProductModal() {
            document.getElementById('modalTitle').textContent = 'Add New Product';
            document.getElementById('formAction').value = 'add_product';
            document.getElementById('productId').value = '';
            document.getElementById('title').value = '';
            document.getElementById('category').value = 'electronics';
            document.getElementById('type').value = 'buy';
            document.getElementById('buyPrice').value = '';
            document.getElementById('rentPrice').value = '';
            document.getElementById('location').value = '';
            document.getElementById('stock').value = '1';
            document.getElementById('lowStockThreshold').value = '3';
            document.getElementById('image').value = '';
            document.getElementById('description').value = '';
            togglePriceFields();
            document.getElementById('productModal').classList.add('active');
        }

        function editProduct(id, title, description, category, type, buyPrice, rentPrice, location, stock, lowStockThreshold, image) {
            document.getElementById('modalTitle').textContent = 'Edit Product';
            document.getElementById('formAction').value = 'update_product';
            document.getElementById('productId').value = id;
            document.getElementById('title').value = title;
            document.getElementById('category').value = category;
            document.getElementById('type').value = type;
            document.getElementById('buyPrice').value = buyPrice === 'null' ? '' : buyPrice;
            document.getElementById('rentPrice').value = rentPrice === 'null' ? '' : rentPrice;
            document.getElementById('location').value = location;
            document.getElementById('stock').value = stock;
            document.getElementById('lowStockThreshold').value = lowStockThreshold;
            document.getElementById('image').value = image;
            document.getElementById('description').value = description;
            togglePriceFields();
            document.getElementById('productModal').classList.add('active');
        }

        function closeModal() {
            document.getElementById('productModal').classList.remove('active');
        }

        function openReplenishModal(productId, productName) {
            currentProductId = productId;
            currentProductName = productName;
            document.getElementById('replenishProductName').innerHTML = 
                '<strong>Product:</strong> ' + productName;
            document.getElementById('replenishModal').classList.add('active');
        }

        function closeReplenishModal() {
            document.getElementById('replenishModal').classList.remove('active');
        }

        function confirmReplenish() {
            const quantity = document.getElementById('replenishQuantity').value;
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=replenish_stock&product_id=' + currentProductId + '&quantity=' + quantity
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    closeReplenishModal();
                    location.reload();
                } else {
                    alert('Error replenishing stock');
                }
            });
        }

        function openConfirmModal(action, id) {
            currentAction = action;
            currentId = id;
            
            const modal = document.getElementById('confirmModal');
            const title = document.getElementById('confirmTitle');
            const message = document.getElementById('confirmMessage');
            const btn = document.getElementById('confirmActionBtn');
            
            if (action === 'delete') {
                title.textContent = 'Delete Product';
                message.textContent = 'Are you sure you want to delete this product? This action cannot be undone.';
                btn.textContent = 'Yes, delete';
            } else if (action === 'accept') {
                title.textContent = 'Accept Order';
                message.textContent = 'Accept this order? Stock will be deducted.';
                btn.textContent = 'Yes, accept';
            } else if (action === 'reject') {
                title.textContent = 'Reject Order';
                message.textContent = 'Reject this order?';
                btn.textContent = 'Yes, reject';
            } else if (action === 'return') {
                title.textContent = 'Mark as Returned';
                message.textContent = 'Mark this rental as returned? Stock will be added back.';
                btn.textContent = 'Yes, return';
            }
            
            modal.classList.add('active');
        }

        function closeConfirmModal() {
            document.getElementById('confirmModal').classList.remove('active');
        }

        document.getElementById('confirmActionBtn').addEventListener('click', function() {
            if (currentAction === 'delete') {
                fetch('', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=delete_product&product_id=' + currentId
                })
                .then(() => location.reload());
            } else if (currentAction === 'accept') {
                updateOrder(currentId, 'confirmed');
            } else if (currentAction === 'reject') {
                updateOrder(currentId, 'cancelled');
            } else if (currentAction === 'return') {
                returnRental(currentId);
            }
            
            closeConfirmModal();
        });

        function updateOrder(orderId, status) {
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=update_order&order_id=' + orderId + '&status=' + status
            })
            .then(() => location.reload());
        }

        function returnRental(orderId) {
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=return_rental&order_id=' + orderId
            })
            .then(() => location.reload());
        }

        function sendReply(buyerId, productId) {
            const message = document.getElementById('replyMessage').value.trim();
            if (!message) return;
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=send_message&receiver_id=' + buyerId + '&product_id=' + productId + '&message=' + encodeURIComponent(message)
            })
            .then(() => {
                // Add message to UI
                const container = document.getElementById('chatMessages');
                const now = new Date();
                const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                
                const messageHtml = `
                    <div class="message sent">
                        ${message}
                        <div class="message-time">${timeStr}</div>
                    </div>
                `;
                
                container.innerHTML += messageHtml;
                document.getElementById('replyMessage').value = '';
                container.scrollTop = container.scrollHeight;
            });
        }

        function openPayoutModal(balance) {
            document.getElementById('availableBalance').textContent = '₱' + balance.toLocaleString();
            document.getElementById('payoutModal').classList.add('active');
        }

        function closePayoutModal() {
            document.getElementById('payoutModal').classList.remove('active');
        }

        function requestPayout() {
            const amount = document.getElementById('payoutAmount').value;
            const method = document.getElementById('payoutMethod').value;
            
            if (!amount || amount < 100) {
                alert('Please enter a valid amount (minimum ₱100)');
                return;
            }
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=request_payout&amount=' + amount + '&method=' + encodeURIComponent(method)
            })
            .then(() => {
                alert('Payout requested successfully!');
                closePayoutModal();
                location.reload();
            });
        }

        // Scroll to bottom of messages
        window.onload = function() {
            const container = document.getElementById('chatMessages');
            if (container) {
                container.scrollTop = container.scrollHeight;
            }
        }
    </script>
</body>
</html>